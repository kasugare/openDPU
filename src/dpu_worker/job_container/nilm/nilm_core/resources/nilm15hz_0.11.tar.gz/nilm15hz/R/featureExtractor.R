#' @title tvFeatureExtractor
#' @author CH
#' @description extract tv block features from total data 
#' @update 2015.12.03
#' @input data : c(timestamp, active_power, reactive_power)
#'        blockSize : time block Size
#' @output features of data blocks


# source(file="edgeDetector.R")
# source(file="cutBlocks.R")

library(stringr)
tvFeatureExtractor <- function(data, blockSize){
  
  
  total_ts <- data[,1]
  total_ap <- data[,2]
  total_rp <- data[,3]
  
  totalApBlock <- cutBlocks(total_ap, blockSize)
  totalRpBlock <- cutBlocks(total_rp, blockSize)
  totalTsBlock <- cutBlocks(total_ts, blockSize)
  
  
  
  # edge features
  type11NumList <- rep(0,nrow(totalApBlock)) # number of Simple R edges in the block
  type12NumList <- rep(0,nrow(totalApBlock)) # number of 'R' with overshooting in the block
  type21NumList <- rep(0,nrow(totalApBlock)) # number of Simple F edges in the block
  type22NumList <- rep(0,nrow(totalApBlock)) # TODO : delete it
  type31NumList <- rep(0,nrow(totalApBlock)) # number of simple impulse in the block
  type32NumList <- rep(0,nrow(totalApBlock)) # number of RFF impulse in the block
  type33NumList <- rep(0,nrow(totalApBlock)) # number of falling impulse in the block
  type34NumList <- rep(0,nrow(totalApBlock)) # number of other impulse in the block
  
  edgeNumList <- rep(0,nrow(totalApBlock)) # numer of edges
  maxSlopeMeanList <- rep(0,nrow(totalApBlock)) # mean maxSlope of edges in the block
  maxSlopeVarList <- rep(0,nrow(totalApBlock)) # var maxSlope of edges in the block
  minSlopeMeanList <- rep(0,nrow(totalApBlock)) # mean minSlope of edges in the block
  minSlopeVarList <- rep(0,nrow(totalApBlock)) # var min Slope of edges in the block
  
  stringLengthMaxList <- rep(0,nrow(totalApBlock)) # max edge string length
  stringLengthMeanList <- rep(0,nrow(totalApBlock)) # mean edge string length
  stringLengthVarList <- rep(0,nrow(totalApBlock)) # var edge string length
  
  # additional edge features
  smallRisingNumList <- rep(0,nrow(totalApBlock)) # number of edges(maxSlope<40)
  smallFallingNumList <- rep(0,nrow(totalApBlock)) # number of edges(minSlope>-40)
  largeImpulseNumList <- rep(0,nrow(totalApBlock)) # number of edges(max slope > 100 & impulse)
  
  # ap features
  medianMinDiffList <- rep(0,nrow(totalApBlock)) # median(blockAp)-min(blockAp)
  quantile1MinDiffList <- rep(0,nrow(totalApBlock)) # quantile(blockAp, 0.25) - min(blockAp)
  meanLargerThanMedianList <- rep(0,nrow(totalApBlock)) # mean>median? (logical)
  
  # 7 diff(0.5 second diff) features
  diff7MeanList <- rep(0,nrow(totalApBlock)) #7 diff mean
  diff7VarList <- rep(0,nrow(totalApBlock)) #7 diff var
  diff7SmallCountList <- rep(0,nrow(totalApBlock)) # number of 7diff(<15)
  diff7LargeCountList <- rep(0,nrow(totalApBlock)) # number of 7diff(>30&<60)
  
  # 30 diff (2 second diff) features
  diff30MeanList <- rep(0,nrow(totalApBlock)) #30 diff mean
  diff30VarList <- rep(0,nrow(totalApBlock)) #30diff var
  diff30SmallCountList <- rep(0,nrow(totalApBlock)) # number of 30diff(<15)
  diff30LargeCountList <- rep(0,nrow(totalApBlock)) # number of 30diff(>30&<60)
  
  # flat features
  flatDiffVarList <- rep(0,nrow(totalApBlock)) # var of flat diff in the block
  flatLengthVarList <- rep(0,nrow(totalApBlock)) # var of flat length in the block
  flatNumList <- rep(0,nrow(totalApBlock)) # flat number in the block
  
  
  
  for (i in 1:nrow(totalApBlock)){
    blockTs <- totalTsBlock[i,]
    blockAp <- totalApBlock[i,]
    blockRp <- totalRpBlock[i,]
    
    dataBlock <- data.frame(cbind(blockTs, blockAp, blockRp))
    colnames(dataBlock) <- c("ts","ap","rp")
    edgeDetectorResult <- edgeDetectorTV(dataBlock)
    edgeList <- edgeDetectorResult[[1]]
    edgeStringList <- edgeDetectorResult[[2]]
    flatList <- edgeDetectorResult[[3]]
    
    if (nrow(edgeStringList)>1){
      stringLengthMax <- max(apply(edgeStringList, MARGIN=1,FUN = nchar))
      stringLengthMean <- mean(apply(edgeStringList, MARGIN=1,FUN = nchar))
      stringLengthVar <- var(apply(edgeStringList, MARGIN=1,FUN = nchar))
    } else if(nrow(edgeStringList)==1){
      stringLengthMax <- apply(edgeStringList, MARGIN = 1, FUN = nchar)
      stringLengthMean <- apply(edgeStringList, MARGIN = 1, FUN = nchar)
      stringLengthVar <- 0
    } else{
      stringLengthMax <- 0
      stringLengthMean <- 0
      stringLengthVar <- 0
    }
    
    stringLengthMaxList[i] <- stringLengthMax
    stringLengthMeanList[i] <- stringLengthMean
    stringLengthVarList[i] <- stringLengthVar
    ## edge statistics features
    # type count
    if (nrow(edgeList)>0){
      type11NumList[i] <- sum(edgeList[,1]==11)
      type12NumList[i] <- sum(edgeList[,1]==12)
      type21NumList[i] <- sum(edgeList[,1]==21)
      type22NumList[i] <- sum(edgeList[,1]==22)
      type31NumList[i] <- sum(edgeList[,1]==31)
      type32NumList[i] <- sum(edgeList[,1]==32)
      type33NumList[i] <- sum(edgeList[,1]==33)
      type34NumList[i] <- sum(edgeList[,1]==34)
    } else{
      type11NumList[i] <- 0
      type12NumList[i] <- 0
      type21NumList[i] <- 0
      type22NumList[i] <- 0
      type31NumList[i] <- 0
      type32NumList[i] <- 0
      type33NumList[i] <- 0
      type34NumList[i] <- 0
    }
    
    edgeNumList[i] = nrow(edgeList)
    
    if (edgeNumList[i] > 1){
      maxSlopeMeanList[i] <- mean(edgeList[,6])
      maxSlopeVarList[i] <- var(edgeList[,6])
      minSlopeMeanList[i] <- mean(edgeList[,8])
      minSlopeVarList[i] <- var(edgeList[,8])
      smallRisingNumList[i] <- sum(edgeList[,6]>0 & edgeList[,6]<40)
      smallFallingNumList[i] <- sum(edgeList[,8]<0 & edgeList[,8]>-40)
      largeImpulseNumList[i] <- sum(edgeList[,6]>100 & (edgeList[,1]== 31 | edgeList[,1] == 32 | edgeList[,1] == 33 | edgeList[,1] == 34))
      
    } else if(edgeNumList[i] == 1){
      maxSlopeMeanList[i] <- edgeList[,6]
      maxSlopeVarList[i] <- 0
      minSlopeMeanList[i] <- edgeList[,8]
      minSlopeVarList[i] <- 0
      smallRisingNumList[i] <- sum(edgeList[,6]>0 & edgeList[,6]<40)
      smallFallingNumList[i] <- sum(edgeList[,8]<0 & edgeList[,8]>-40)
      largeImpulseNumList[i] <- sum(edgeList[,6]>100 & (edgeList[,1]== 31 | edgeList[,1] == 32 | edgeList[,1] == 33 | edgeList[,1] == 34))
    } else {
      maxSlopeMeanList[i] <- 0
      maxSlopeVarList[i] <- 0
      minSlopeMeanList[i] <- 0
      minSlopeVarList[i] <- 0
      smallRisingNumList[i] <- 0
      smallFallingNumList[i] <- 0
      largeImpulseNumList[i] <- 0
    }
    
    
    
    
    
    ## flat features
    if (nrow(flatList)>1){
      flatDiff <- blockAp[flatList[,2]] - blockAp[flatList[,1]]
      flatDiffVarList[i] <- var(flatDiff)
      flatLengthVarList[i] <- var(flatList[,3])
    } else{
      flatDiffVarList[i] <- 0
      flatLengthVarList[i] <- 0
    }
    flatNumList[i] <- nrow(flatList)
    ## ap features
    medianMinDiffList[i] <- median(blockAp) - min(blockAp);
    quantile1MinDiffList[i] <- quantile(blockAp, 0.25, 4) - min(blockAp)
    meanLargerThanMedianList[i] <- mean(blockAp)>median(blockAp)
    
    # 7 diff features
    diff7 <- blockAp[8:length(blockAp)] - blockAp[1:(length(blockAp)-7)]
    diff7MeanList[i] <- mean(diff7)
    diff7VarList[i] <- var(diff7)
    diff7SmallCountList[i] <- sum(abs(diff7)<15)
    diff7LargeCountList[i] <- sum(abs(diff7)>30 & abs(diff7)<60)
    
    # 30 diff features
    diff30 <- blockAp[31:length(blockAp)] - blockAp[1:(length(blockAp)-30)]
    diff30MeanList[i] <- mean(diff30)
    diff30VarList[i] <- var(diff30)
    diff30SmallCountList[i] <- sum(abs(diff30)<15)
    diff30LargeCountList[i] <- sum(abs(diff30)>30 & abs(diff30)<60)
    
  }
    
    featureTable <- cbind(type11NumList, type12NumList, type21NumList, type22NumList, type31NumList, type32NumList,
                         type33NumList, type34NumList, edgeNumList, maxSlopeMeanList, maxSlopeVarList, minSlopeMeanList, minSlopeVarList,
                         smallRisingNumList, smallFallingNumList, largeImpulseNumList, medianMinDiffList, quantile1MinDiffList, meanLargerThanMedianList,
                         stringLengthMaxList, stringLengthMeanList, stringLengthVarList, diff7MeanList, diff7VarList, diff7SmallCountList, diff7LargeCountList,
                         diff30MeanList, diff30VarList, diff30SmallCountList, diff30LargeCountList, flatDiffVarList, flatLengthVarList, flatNumList)
    
    return(featureTable)
    
}
