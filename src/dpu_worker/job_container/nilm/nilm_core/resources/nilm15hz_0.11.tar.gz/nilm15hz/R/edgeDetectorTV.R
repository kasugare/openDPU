#' @title edgeDetector
#' @author (author) prof. / (interpreter) CH
#' @description interpreted version of MATLAB edgeDetector
#' @update 2015.12.01
#' @input the result of getDataFromCSV(ts, rp, ap, idx table)
#' @output transient vectors
#'         type : edge type, e.g. 1X -> rising edge, 2X -> falling edge, 3X-> impulse, -1 -> unknown
#'         startIndex : transient start index
#'         endIndex : transient end index
#'         endStartAp : steadystateHeightAp in old version, (Ap after transient - Ap before transient), for impulse check. 
#'         endStartRp : steadystateHeightRp in old version, (Rp after transient - Rp before transient), for impulse check.
#'         maxStartAp : maximum Ap after the start of tranisent
#'         maxStartRp : maximum Rp after the start of tranisent#'
#'         mixStartAp : minimum Ap after the start of tranisent
#'         mixStartRp : minimum Rp after the start of tranisent
#'         numTransAp : the number of points that change Ap compared to (i-1)th point. e.g.) 1 1 3 ->1, 2 0 5 -> 2
#'         numSegmentsAp : the number of segments. e.g. RF -> 2, R->1, RFRRFR ->6
#'         maxSlopeAp : maximum Ap slope
#'         maxSlopeRp : maximum Rp slope
#'         minSlopeAp : minimum Ap slope
#'         minSlopeRp : minimum Rp slope
#'         edgeSequence : the sequence of edges in transient. e.g. RF, R, , RRF 
#' @update 2015.12.01 : flatSectionList가 비어있는 경우 처리.         

library(pracma)
library(gdata)

edgeDetectorTV <- function(data) {
  ##
  # EDGEDETECTOR Summary of this function goes here
  #
  # TODO: Rising edge should be modeled as an object (or strucutre or class
  # or a container depending on language in use)
  
  
  ## Handle sign errors of raw data. This can happen due to installation
  #  problem.
  
  colnames(data) <- c("ts", "ap", "rp")
  
  if (mean(data$ap) < 0) {
    data$ap <- -data$ap 
  }
  if (mean(data$rp) < 0) {
    data$rp <- -data$rp 
  }
  
  ## -------------------------------------------------------------
  # Define parameters
  SAMPLING_RATE <- 15 # 15Hz sampling
  UNIT_TIME <- 3600 # 1.0 in dataTs correspondes to 3600
  # s <- sprintf('SAMPLING_RATE = %d',SAMPLING_RATE)
  # print(s)
  # s <- sprintf('UNIT_TIME = %d seconds corredponds to 1.0 in dataTs',UNIT_TIME)
  # print(s)
  
  
  # Slope threshold to declare FLAT
  FLAT_SLOPE_THRESH <- 1 # Per sample (trainslates to 15W/sec)
  # Slope thrshold to declare
  RF_SLOPE_THRESH <- 7 # Per sample (translates to 105W/sec)
  
  # Min length to be flatSection
  FLAT_LENGTH_THRESH <- 7 # At least this number of samples
  
  # Max number of missing samples for evaluation
  MAX_MISS_SAMPLES_SECS <- 1 # Up to 1 sec of missing samples are ignored.
  # Max time allowed for 'consecutive missing samples' to be valid. Scale properly
  CONS_MISS_SAMPLES_MAXTIME_THRESH <- MAX_MISS_SAMPLES_SECS/UNIT_TIME 
  
  
  # Impulse removal related
  MAX_IMP_LENGTH_SECS <- 20 # Upto 20seconds for an impulse
  IMP_TIME_THRESH <- MAX_IMP_LENGTH_SECS/UNIT_TIME
  
  SIM_POWER_LEVEL_MARGIN <- 3.0 # Similar power level margin
  POWER_DIFF_THRESH <- 10.0 # At least this much needed to declare an appliance on or off event
  
  # Transient classification related
  MIN_MAX_AP_THRESH <- 7.0 # At least this much of fluctuation needed to be considered as a transient
  GEN_EDGE_LENGTH_THRESH <- 3 # The length of generalized-edge needs to be at least as long as this value
  
  FR_FLAT_ADD_RATIO_THRESH <- 0.1 # Ratio of difference between left and right peaks of FR compared to impulse's height
  
  # tag types
  FLAT <- 0
  RISING <- 1
  FALLING <- -1
  UNKNOWN <- -99
  
  # Diff
  diffVecAp <- diff(data$ap, lag = 1) 
  diffVecRp <- diff(data$rp, lag = 1) 
  diffVecTs <- diff(data$ts, lag = 1) 
  diffVecAp[length(diffVecAp)+1] <- 0 # zero-pad the last sample
  diffVecRp[length(diffVecRp)+1] <- 0 # zero-pad the last sample
  diffVecTs[length(diffVecTs)+1] <- 1/SAMPLING_RATE # Pad with a number
  ## -------------------------------------------------------------
  DATA_LENGTH <- dim(data)[1]
  ## Per sample tags
  tagsAp <- rep(1, DATA_LENGTH) * UNKNOWN
  tagsRp <- rep(1, DATA_LENGTH) * UNKNOWN
  
  
  
  tagsAp[abs(diffVecAp) <= FLAT_SLOPE_THRESH] <- FLAT
  tagsAp[diffVecAp <= -1*RF_SLOPE_THRESH] <- FALLING
  tagsAp[RF_SLOPE_THRESH <= diffVecAp] <- RISING
  
  tagsRp[abs(diffVecRp) <= FLAT_SLOPE_THRESH] <- FLAT
  tagsRp[diffVecRp <= (-1) * RF_SLOPE_THRESH] <- FALLING
  tagsRp[RF_SLOPE_THRESH <= diffVecRp] <- RISING
  
  
  # Deal with missing data samples
  tagsAp[CONS_MISS_SAMPLES_MAXTIME_THRESH < diffVecTs] <- UNKNOWN
  tagsRp[CONS_MISS_SAMPLES_MAXTIME_THRESH < diffVecTs] <- UNKNOWN
  
  
  ## -------------------------------------------------------------
  # Detect stable/absolutely FLAT sections
  
  # Mentality : try to detect short sections of stable FLAT's
  lengthTags <- length(tagsAp)
  
  # if length(tagsRp ~= lengthTags)
  #   error('Lengths of AP and RP do not match. Pre-processing error.')
  # end
  
  # Initialize
  NUM_ATTRIBUTES <- 4
  flatSectionList <- matrix(0,lengthTags, NUM_ATTRIBUTES)
  numFlatSections <- 0
  
  
  
  k <- 1
  while(1)
  {
    if (tagsAp[k]==FLAT && tagsRp[k]==FLAT) # Use AND rule: both AP and RP need to be FLAT
    {
      
      flatStartIndex <- k
      k <- k+1
      while (tagsAp[k] == FLAT && tagsRp[k] == FLAT)
      {
        k <- k+1
        if (k >= lengthTags)
        {
          break
        }
      }
      flatEndIndex <- k
      flatLength <- flatEndIndex - flatStartIndex
      flatStartPowerAp <- data$ap[flatStartIndex]
      
      # Chunk length only. Ignore power deviation as the flat section becomes large - very low slope everywhere, anyway
      if (flatLength >= FLAT_LENGTH_THRESH)
      {
        numFlatSections <- numFlatSections+1
        flatSectionList[numFlatSections,] <- c(flatStartIndex,flatEndIndex,flatLength,flatStartPowerAp)
      }
    }
    
    k <- k+1
    
    # Check if all done
    if (k >= length(data$ap))
    {
      break
    }
  }
  
  # Truncate
  flatSectionList = flatSectionList[1:numFlatSections,]
  
  ## -------------------------------------------------------------
  # Flat removal
  # Remove flat sections that are part of impulse
  
  keepList <- vector() # Keep the first flatSection
  keepList[1] <- 1
  
  if(numFlatSections>2){# 12.01 update : flatSectionList가 비어있는 경우 handling.
    for (k in 2:(nrow(flatSectionList)-1))
    {
      
      # condition 1 : Time-wise, prev and next flatSections are close enough
      # condition 2 : Power levels of prev and next flatSections are similar
      # condition 3 : Middle flatSection needs to be higher power
      
      if ((data$ts[flatSectionList[k+1,1]] - data$ts[flatSectionList[k-1,2]])< IMP_TIME_THRESH
          && abs(data$ap[flatSectionList[k+1,1]] - data$ap[flatSectionList[k-1,2]]) < SIM_POWER_LEVEL_MARGIN
          && POWER_DIFF_THRESH <= (min(data$ap[flatSectionList[k,1]:flatSectionList[k,2]]) - data$ap[flatSectionList[k-1,2]]))
      {
        # Do nothing. This will cause k'th flat section to be removed
      }
      else
      {
        keepList <- rbind(keepList, k)
      }
    }
  }
  
  keepList <- rbind(keepList, nrow(flatSectionList))
  # Remove flats inside of impulse shapes
  if (!is.null(nrow(flatSectionList))){
    flatSectionList <- flatSectionList[keepList,]
  }
  ####12.01 update start
  #keepList <- keepList[keepList>0]
  #if (nrow(flatSectionList) > 0){
  #  flatSectionList = unique(flatSectionList[which(keepList>0),])
  #}
  ####12.01 update end
  
  
  ## -------------------------------------------------------------
  # Flat addition
  # Add flat sections when between
  
  newFlat <- vector()
  if (!is.null(nrow(flatSectionList))){
    for (k in 1:(nrow(flatSectionList)-1))
    {
      # A genEdge
      startIndex <- flatSectionList[k,2] # [flatStartIndex flatEndIndex flatLength flatStartPowerAp]
      endIndex <- flatSectionList[k+1,1]
      genEdgeLength <- endIndex - startIndex + 1 # Transient
      
      # Vector to investigate
      dataApLocal <- data$ap[startIndex:endIndex]
      diffVecTsLocal <- diffVecTs[startIndex:endIndex-1]
      
      # Features
      maxAp <- max(dataApLocal)
      minAp <- min(dataApLocal)
      
      # Ignore if FLAT-like, too short, or too many missing data points
      if ((maxAp - minAp) < MIN_MAX_AP_THRESH || genEdgeLength < GEN_EDGE_LENGTH_THRESH)
      {
        next
      }
      
      # Create a summary table of FALLING and RISING streaks
      streakList <- data.frame()
      j <- startIndex
      
      while(1)
      {
        type <- tagsAp[j]
        sIndex <- j
        j <- j+1
        while (tagsAp[j] == type)
        {
          j <- j+1
          if(j>=endIndex)
          {
            break
          }
        }
        eIndex <- j
        
        if (type==FALLING || type == RISING)
        {
          streakList <- rbind(streakList, c(type, sIndex, eIndex, data$ap[sIndex], data$ap[eIndex]))
        }
        if (j >= endIndex)
        {
          break
        } 
      }
      
      # Merge consecutive FALLING's and consecutive Rising's
      streakListMerged <- data.frame()
      if (2 <= nrow(streakList))
      {
        n <- 1
        while (1)
        {
          prevVec <- streakList[n,]
          n <- n+1
          if (nrow(streakList) < n)
          {
            break
          }
          while (prevVec[1] == streakList[n,1])
          {
            # merge
            prevVec[3] <- streakList[n,3]
            prevVec[5] <- streakList[n,5]
            n <- n+1
            if (nrow(streakList) < n)
            {
              break
            }
          }
          streakListMerged <- rbind(streakListMerged, prevVec)
          if (nrow(streakList) < n)
          {
            break
          }
        }
      }
      else
      {
        streakListMerged <- streakList
      }
      
      # Check if FALLING -> RISING happens
      # If a proper condition is met, add the min value point to the newFlat
      if (nrow(streakListMerged) > 1)
      {
        for (n in 1:(nrow(streakListMerged)-1))
        {
          if ((streakListMerged[n,1] == FALLING) && (streakListMerged[n+1,1] == RISING)
              && ((abs(streakListMerged[n,4] - streakListMerged[n+1,5]) <= SIM_POWER_LEVEL_MARGIN)
                  || (abs(streakListMerged[n,4] - streakListMerged[n+1,5]) <= (streakListMerged[n,4] - streakListMerged[n,5])*FR_FLAT_ADD_RATIO_THRESH)))
          {
            ind <- which.min(data$ap[streakListMerged[n,3]:streakListMerged[n+1,2]])
            newFlat <- rbind(newFlat, streakListMerged[n,3] + ind - 1)
          }
        }
      }
    }
  } else{#### 12.01 update start
    # flat section이 비어있는 경우 handling : 처음과 끝을 flat으로 놓음. 
    # A genEdge
    startIndex <- 1 # [flatStartIndex flatEndIndex flatLength flatStartPowerAp]
    endIndex <- length(data$ts)
    genEdgeLength <- endIndex - startIndex + 1 # Transient
    
    # Vector to investigate
    dataApLocal <- data$ap[startIndex:endIndex]
    diffVecTsLocal <- diffVecTs[startIndex:(endIndex-1)]
    
    # Features
    maxAp <- max(dataApLocal)
    minAp <- min(dataApLocal)
    
    # Ignore if FLAT-like, too short, or too many missing data points
    if ((maxAp - minAp) < MIN_MAX_AP_THRESH || genEdgeLength < GEN_EDGE_LENGTH_THRESH){}
    
    # Create a summary table of FALLING and RISING streaks
    streakList <- data.frame()
    j <- startIndex
    
    while(1)
    {
      type <- tagsAp[j]
      sIndex <- j
      j <- j+1
      while (tagsAp[j] == type)
      {
        j <- j+1
        if(j>=endIndex)
        {
          break
        }
      }
      eIndex <- j
      
      if (type==FALLING || type == RISING)
      {
        streakList <- rbind(streakList, c(type, sIndex, eIndex, data$ap[sIndex], data$ap[eIndex]))
      }
      if (j >= endIndex)
      {
        break
      } 
    }
    
    # Merge consecutive FALLING's and consecutive Rising's
    streakListMerged <- data.frame()
    if (2 <= nrow(streakList))
    {
      n <- 1
      while (1)
      {
        prevVec <- streakList[n,]
        n <- n+1
        if (nrow(streakList) < n)
        {
          break
        }
        while (prevVec[1] == streakList[n,1])
        {
          # merge
          prevVec[3] <- streakList[n,3]
          prevVec[5] <- streakList[n,5]
          n <- n+1
          if (nrow(streakList) < n)
          {
            break
          }
        }
        streakListMerged <- rbind(streakListMerged, prevVec)
        if (nrow(streakList) < n)
        {
          break
        }
      }
    }
    else
    {
      streakListMerged <- streakList
    }
    
    # Check if FALLING -> RISING happens
    # If a proper condition is met, add the min value point to the newFlat
    if (nrow(streakListMerged) > 1)
    {
      for (n in 1:(nrow(streakListMerged)-1))
      {
        if ((streakListMerged[n,1] == FALLING) && (streakListMerged[n+1,1] == RISING)
            && ((abs(streakListMerged[n,4] - streakListMerged[n+1,5]) <= SIM_POWER_LEVEL_MARGIN)
                || (abs(streakListMerged[n,4] - streakListMerged[n+1,5]) <= (streakListMerged[n,4] - streakListMerged[n,5])*FR_FLAT_ADD_RATIO_THRESH)))
        {
          ind <- which.min(data$ap[streakListMerged[n,3]:streakListMerged[n+1,2]])
          newFlat <- rbind(newFlat, streakListMerged[n,3] + ind - 1)
        }
      }
    }
  }
  ### 12.01 update end
  
  # Add the new flats (point-flats) to the list
  flatSectionListNew <- cbind(newFlat, newFlat, rep(1, length(newFlat)), data$ap[newFlat])
  flatSectionList <- rbind(flatSectionList, flatSectionListNew) # Merge
  flatSectionList <- flatSectionList[order(flatSectionList[,1]),]
  
  
  
  ## -------------------------------------------------------------
  # Classify generalized-edges between FLAT's
  
  
  # Initialize
  NUM_ATTRIBUTES <- 15
  
  
  if (!is.null(nrow(flatSectionList))){ # 12.01 update
    genEdgeList <- matrix(0, nrow(flatSectionList)-1, NUM_ATTRIBUTES )
    numEdges <- 0
    genEdgeStringList <- rep('', nrow(flatSectionList)-1)
    for (k in 1:(nrow(flatSectionList)-1))
    {
      previousFlatSection <- flatSectionList[k,] # [flatStartIndex flatEndIndex flatLength flatStartPowerAp]
      nextFlatSection <- flatSectionList[k+1,]
      
      startIndex <- previousFlatSection[2]
      endIndex <- nextFlatSection[1]
      genEdgeLength <- endIndex - startIndex + 1
      
      # Vector to investigate
      dataApLocal <- data$ap[startIndex:endIndex]
      diffVecTsLocal <- diffVecTs[startIndex:(endIndex-1)]
      
      
      
      # Features
      maxAp <- max(dataApLocal)
      minAp <- min(dataApLocal)
      
      # Ignore if FLAT-like, too short, or too many missing data points
      if ((maxAp - minAp) < MIN_MAX_AP_THRESH || genEdgeLength < GEN_EDGE_LENGTH_THRESH)
      {
        next
      }
      
      # Vector to investigate: additional
      diffVecApLocal <- diffVecAp[startIndex:(endIndex-1)]
      
      dataRpLocal <- data$rp[startIndex:endIndex]
      diffVecRpLocal <- diffVecRp[startIndex:(endIndex-1)]
      
      tagsApLocal <- tagsAp[startIndex:(endIndex-1)]
      tagsRpLocal <- tagsRp[startIndex:(endIndex-1)]
      
      #browser()
      
      # Features
      startAp <- dataApLocal[1]
      endAp <- dataApLocal[length(dataApLocal)]
      
      startRp <- dataRpLocal[1]
      endRp <- dataRpLocal[length(dataRpLocal)]
      maxRp <- max(dataRpLocal)
      minRp <- min(dataRpLocal)
      
      endStartAp <- endAp - startAp
      maxStartAp <- maxAp - startAp
      minStartAp <- minAp - startAp
      
      endStartRp <- endRp - startRp
      maxStartRp <- maxRp - startRp
      minStartRp <- minRp - startRp
      
      maxSlopeAp <- max(diffVecApLocal)
      minSlopeAp <- min(diffVecApLocal)
      
      maxSlopeRp <- max(diffVecRpLocal)
      minSlopeRp <- min(diffVecRpLocal)
      
      numTransAp <- sum(tagsApLocal[1:(length(tagsApLocal)-1)] != tagsApLocal[2:length(tagsApLocal)])
      numTransRp <- sum(tagsRpLocal[1:(length(tagsRpLocal)-1)] != tagsRpLocal[2:length(tagsRpLocal)])
      
      numSegmentsAp <- 0
      shapeAlphabet <- ''
      type <- 'U'
      for (j in 1:length(tagsApLocal))
      {
        if (tagsApLocal[j] == RISING)
        {
          if (type != 'R')
          {
            shapeAlphabet <- paste(shapeAlphabet, 'R', sep = "")
            numSegmentsAp <- numSegmentsAp + 1
            type <- 'R'
          }
        }
        else if (tagsApLocal[j] == FALLING)
        {
          if (type != 'F')
          {
            shapeAlphabet <- paste(shapeAlphabet, 'F', sep = "")
            numSegmentsAp <- numSegmentsAp + 1
            type <- 'F'
          }
        }
        else
        {
          type <- 'U'
        }
        
        
      }
      
      type <- -1
      
      
      
      if(strcmp(shapeAlphabet, 'R') && POWER_DIFF_THRESH < endStartAp)
      {
        # Simple R
        type <- 11
      }
      else if(strcmp(shapeAlphabet, 'RF') && POWER_DIFF_THRESH < endStartAp)
      {
        # 'R' with overshooting
        type <- 12
      }
      else if(strcmp(shapeAlphabet, 'F') && endStartAp < (-1)*POWER_DIFF_THRESH)
      {
        # Simple 'F'
        type <- 21
      }
      else if(strcmp(shapeAlphabet, 'RF') && abs(endStartAp)<=SIM_POWER_LEVEL_MARGIN)
      {
        # Simple impulse
        type <- 31
      }
      else if(strcmp(shapeAlphabet, 'RFF') && abs(endStartAp)<=SIM_POWER_LEVEL_MARGIN)
      {
        # RFF impulse
        type <- 32
      }
      else if(substr(shapeAlphabet,1,1)=='F' && abs(endStartAp)<=SIM_POWER_LEVEL_MARGIN) #12.01 update
      {
        # falling impulse
        type <- 33
      }
      else if(abs(endStartAp)<=SIM_POWER_LEVEL_MARGIN)
      {
        # Other impulses
        type <- 34
      }
      
      
      
      edgeInfo <- c(type, startIndex, endIndex, endStartAp, endStartRp, maxStartAp, maxStartRp, minStartAp, minStartRp,
                    numTransAp, numSegmentsAp, maxSlopeAp, maxSlopeRp, minSlopeAp, minSlopeRp)
      
      
      # Now update genEdgeList
      numEdges <- numEdges + 1
      genEdgeList[numEdges,] <- edgeInfo
      genEdgeStringList[numEdges] <- shapeAlphabet
    }
  } else{ #### 12.01 update start
    # flatSectionList가 비어있는 경우 handling : 처음과 끝을 flat으로 놓음. 
    
    genEdgeList <- data.frame()
    numEdges <- 0
    genEdgeStringList <- data.frame()
    
    startIndex <- 1
    endIndex <- length(data$ts)
    genEdgeLength <- endIndex - startIndex + 1
    
    # Vector to investigate
    dataApLocal <- data$ap[startIndex:endIndex]
    diffVecTsLocal <- diffVecTs[startIndex:(endIndex-1)]
    
    
    
    # Features
    maxAp <- max(dataApLocal)
    minAp <- min(dataApLocal)
    
    # Ignore if FLAT-like, too short, or too many missing data points
    if (!((maxAp - minAp) < MIN_MAX_AP_THRESH)&&!(genEdgeLength < GEN_EDGE_LENGTH_THRESH)){
      
      # Vector to investigate: additional
      diffVecApLocal <- diffVecAp[startIndex:(endIndex-1)]
      
      dataRpLocal <- data$rp[startIndex:endIndex]
      diffVecRpLocal <- diffVecRp[startIndex:(endIndex-1)]
      
      tagsApLocal <- tagsAp[startIndex:(endIndex-1)]
      tagsRpLocal <- tagsRp[startIndex:(endIndex-1)]
      
      #browser()
      
      # Features
      startAp <- dataApLocal[1]
      endAp <- dataApLocal[length(dataApLocal)]
      
      startRp <- dataRpLocal[1]
      endRp <- dataRpLocal[length(dataRpLocal)]
      maxRp <- max(dataRpLocal)
      minRp <- min(dataRpLocal)
      
      endStartAp <- endAp - startAp
      maxStartAp <- maxAp - startAp
      minStartAp <- minAp - startAp
      
      endStartRp <- endRp - startRp
      maxStartRp <- maxRp - startRp
      minStartRp <- minRp - startRp
      
      maxSlopeAp <- max(diffVecApLocal)
      minSlopeAp <- min(diffVecApLocal)
      
      maxSlopeRp <- max(diffVecRpLocal)
      minSlopeRp <- min(diffVecRpLocal)
      
      numTransAp <- sum(tagsApLocal[1:(length(tagsApLocal)-1)] != tagsApLocal[2:length(tagsApLocal)])
      numTransRp <- sum(tagsRpLocal[1:(length(tagsRpLocal)-1)] != tagsRpLocal[2:length(tagsRpLocal)])
      
      numSegmentsAp <- 0
      shapeAlphabet <- ''
      type <- 'U'
      for (j in 1:length(tagsApLocal))
      {
        if (tagsApLocal[j] == RISING)
        {
          if (type != 'R')
          {
            shapeAlphabet <- paste(shapeAlphabet, 'R', sep = "")
            numSegmentsAp <- numSegmentsAp + 1
            type <- 'R'
          }
        }
        else if (tagsApLocal[j] == FALLING)
        {
          if (type != 'F')
          {
            shapeAlphabet <- paste(shapeAlphabet, 'F', sep = "")
            numSegmentsAp <- numSegmentsAp + 1
            type <- 'F'
          }
        }
        else
        {
          type <- 'U'
        }
        
        
      }
      
      type <- -1
      
      
      if(strcmp(shapeAlphabet, 'R') && POWER_DIFF_THRESH < endStartAp)
      {
        # Simple R
        type <- 11
      }
      else if(strcmp(shapeAlphabet, 'RF') && POWER_DIFF_THRESH < endStartAp)
      {
        # 'R' with overshooting
        type <- 12
      }
      else if(strcmp(shapeAlphabet, 'F') && endStartAp < (-1)*POWER_DIFF_THRESH)
      {
        # Simple 'F'
        type <- 21
      }
      else if(strcmp(shapeAlphabet, 'RF') && abs(endStartAp)<=SIM_POWER_LEVEL_MARGIN)
      {
        # Simple impulse
        type <- 31
      }
      else if(strcmp(shapeAlphabet, 'RFF') && abs(endStartAp)<=SIM_POWER_LEVEL_MARGIN)
      {
        # RFF impulse
        type <- 32
      }
      else if(substr(shapeAlphabet,1,1)=='F' && abs(endStartAp)<=SIM_POWER_LEVEL_MARGIN) #12.01 update
      {
        # falling impulse
        type <- 33
      }
      else if(abs(endStartAp)<=SIM_POWER_LEVEL_MARGIN)
      {
        # Other impulses
        type <- 34
      }
      
      
      edgeInfo <- c(type, startIndex, endIndex, endStartAp, endStartRp, maxStartAp, maxStartRp, minStartAp, minStartRp,
                    numTransAp, numSegmentsAp, maxSlopeAp, maxSlopeRp, minSlopeAp, minSlopeRp)
      
      
      # Now update genEdgeList
      numEdges <- numEdges + 1
      genEdgeList <- edgeInfo
      genEdgeStringList <-rbind(genEdgeStringList, shapeAlphabet)
    }
  }#### 12.01 update end
  
  # Truncate
  if ((!is.null(nrow(genEdgeList)))&&numEdges>0){
    genEdgeList <- as.data.frame(genEdgeList[1:numEdges,])
    if (numEdges==1){
      genEdgeList <- t(genEdgeList)
    }
    colnames(genEdgeList) <- c("type", "startIndex", "endIndex", "endStartAp", "endStartRp", "maxStartAp", "maxStartRp", "minStartAp", "minStartRp",
                               "numTransAp", "numSegmentsAp", "maxSlopeAp", "maxSlopeRp", "minSlopeAp", "minSlopeRp")
    genEdgeStringList <- as.data.frame(genEdgeStringList[1:numEdges])
    colnames(genEdgeStringList) <- "edgeString"
  } else if(numEdges==1){
    genEdgeList <- as.data.frame(t(genEdgeList))
    colnames(genEdgeList) <- c("type", "startIndex", "endIndex", "endStartAp", "endStartRp", "maxStartAp", "maxStartRp", "minStartAp", "minStartRp",
                               "numTransAp", "numSegmentsAp", "maxSlopeAp", "maxSlopeRp", "minSlopeAp", "minSlopeRp")
    genEdgeStringList <- as.data.frame(genEdgeStringList[1:numEdges])
    colnames(genEdgeStringList) <- "edgeString"
  } else{
    genEdgeList <- data.frame()
    genEdgeStringList <- data.frame()
  }

  
  # 12.01 update : flatSectionList error handling
  if (is.null(nrow(flatSectionList))){
    flatSectionList <- data.frame(t(flatSectionList))
  }
  
  if (flatSectionList[1,1]==0&&flatSectionList[1,2]==0&&flatSectionList[1,3]==0&&flatSectionList[1,1]==0){
    flatSectionList = flatSectionList[-1,]
  }
  
  if (is.null(nrow(flatSectionList))){
    flatSectionList <- data.frame(t(flatSectionList))
  }

  colnames(flatSectionList) <- c("flatStartIndex","flatEndIndex", "flatLength", "flatStartPowerAp")
  

  
  return(list("edgeList"=genEdgeList, "edgeStringList" = genEdgeStringList, "flatList" = flatSectionList))
  
  # 12.01 delete
  #edgeInfoTable <- cbind(genEdgeList, genEdgeStringList, flatSectionList)
  #colnames(edgeInfoTable) <- c("type", "startIndex", "endIndex", "endStartAp", "endStartRp", "maxStartAp", "maxStartRp", "minStartAp", "minStartRp",
  #                             "numTransAp", "numSegmentsAp", "maxSlopeAp", "maxSlopeRp", "minSlopeAp", "minSlopeRp", "edgeSequence", "flatStartIndex",
  #                             "flatEndIndex", "flatLength", "flatStartPowerAp")
  
  #return(edgeInfoTable)
  
}