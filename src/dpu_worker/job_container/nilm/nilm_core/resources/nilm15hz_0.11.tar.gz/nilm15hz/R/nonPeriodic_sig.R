generate.PatternScan.meta.ricecooker_1Hz <- function (data, eff_size, periodicity, thres_ap.h, thres_rp.delta){
  
  # parameters
  search_iter <- 1000
  warming.min_minute <- 4.5 # examine each lump to check 'med.t' 
  warming.lump.min_gap.minute <- 30 # lumps within x min. are merged when searching cooking (Also, this value should be larger than or equal to 'cooking.max_t.minute' to avoid an overlapped power estimation.)
  warming.sec_margin <- 3 # x second margin on median time  
  
  wnc_max.hr.gap <- 4 # time interval between warming & cooking 
  
  
  cooking.min_watt <- 800
  cooking.med_watt <- 1200
  cooking.max_watt <- 1600
  
  
  # cooking.min_Wh <- 30 # Wh
  cooking.min_t.minute <- 4 # to choose the right candidate
  cooking.min_fluctuation.num <- 0 # to choose the right candidate
  
  cooking.max_t.minute <- 30 # this value should be smaller than or equal to 'cooking.max_t.minute' to avoid an overlapped power estimation.
  
  cooking.cand_split.watt <- 400
  
  # cooking information refinement (based on median values)
  r.sub.delta_margin <- 45
  r.delta_margin <- 150 # watt
  r.time.gap.minute_margin <- 60
  r.cooking.minute_margin <- 8 
  
  # examine raw data
  data <- data[order(data$timestamp),] 
  #   time.diff <- diff(as.numeric(data$timestamp))
  #   cat("strange time difference percentage in data:", length(time.diff[time.diff<0.9])/length(time.diff) * 100  , "\n")
  
  
  s.pattern <- DetectPattern_1Hz_new_modifiedforRicecooker(data, position = "start", main_type = "active", sub_type = "reactive")
  
  s.pattern <- s.pattern[order(s.pattern$start.idx),] 
  
  # medium-power signals for warming
  s.pattern.warming1 <- subset(s.pattern, (h1 >= thres_ap.h) & (abs(sub.delta) <= thres_rp.delta) & !is.na(min.slope) ) # original set
  s.pattern.warming2 <- subset(s.pattern, (h1 >= thres_ap.h) & is.na(min.slope) ) # added set
  
  s.pattern.warming <- rbind(s.pattern.warming1, s.pattern.warming2)
  s.pattern.warming <- s.pattern.warming[order(s.pattern.warming$start.idx),] 
  
  s.info <- list()
  s.info <- DetectGroup_15Hz_1D(s.pattern.warming, resolution = search_iter, p_factor = periodicity, group_size = eff_size )
  
  json.candidate <- list()
  json.result <- list()
  str.t <- as.character(min(data$timestamp))
  end.t <- as.character(max(data$timestamp))
  
  stored_lump.summary <- list()
  stored_eff.cooking_info <- list()
  stored_lump.log <- list()
  stored_med_time <- list()
  
  if (length(s.info) == 0) {
    print("Detection for ricecooker has failed.")
    return(list())
  } else {
    
    s.list <- s.info[[length(s.info)]]
    s.list <- subset(s.list, med.t <= warming.min_minute*60)
    
    if (nrow(s.list) == 0) {
      print("Detection for ricecooker has failed.")
      return(list())
      
    } else {
      print("groups for warming mode:")
      print(s.list)
      
      # high-power signals for cooking (naive)
      s.pattern.cooking <- cooking.candidate.search(data, start.pattern = s.pattern, min_watt = cooking.min_watt, max_watt = cooking.max_watt, 
                                                    min_t.minute = cooking.min_t.minute, max_t.minute = cooking.max_t.minute, min_fluc.num = cooking.min_fluctuation.num)
      
      # examine candidates for warming mode
      for (w_idx in 1:nrow(s.list)) {
        
        print(w_idx)
        chosen.s.info <- s.info[[as.numeric(row.names(s.list[w_idx,])) ]]
        lump.idx <- c(0, which(diff(as.numeric(chosen.s.info$start.timestamp)) >= warming.min_minute*60 ), nrow(chosen.s.info))
        chosen.lump <- which(diff(lump.idx) >= eff_size)
        
        if (length(chosen.lump) >0) {
          
          lump_log <- list()
          
          for (l_idx in 1:length(chosen.lump)) {
            
            tmp.start.idx <- lump.idx[chosen.lump[l_idx]] +1
            tmp.end.idx <- lump.idx[chosen.lump[l_idx]+1]
            
            #             tmp.start.timestamp <- chosen.s.info$start.timestamp[tmp.start.idx]
            #             tmp.end.timestamp <- chosen.s.info$end.timestamp[tmp.end.idx]
            #             print(tmp.start.timestamp %--% tmp.end.timestamp)
            
            lump_log[[length(lump_log)+1]] <- data.frame(chosen.s.info[tmp.start.idx:tmp.end.idx,], lump_idx = l_idx )
            
          }
          
          lump_log.total <- rbind.fill(lump_log) 
          
          lump_summary <- ddply(lump_log.total, .(lump_idx), summarize, sum = length(start.timestamp), med.t = median(diff(as.numeric(start.timestamp))) )
          
          tmp.med_time <- lump_summary$med.t[which.max(lump_summary$sum)]
          
          lump_summary <- subset(lump_summary, med.t >= (tmp.med_time - warming.sec_margin) & 
                                   med.t <= (tmp.med_time + warming.sec_margin) )
          
          lump_log.total <- rbind.fill(lump_log[lump_summary$lump_idx])
          
          lump_summary <- ddply(lump_log.total, .(lump_idx), summarize, sum = length(start.timestamp), lump.start = min(start.timestamp), lump.end = max(end.timestamp), lump.duration = as.numeric(lump.end) - as.numeric(lump.start),
                                min.t = min(diff(as.numeric(start.timestamp))), med.t = median(diff(as.numeric(start.timestamp))), min.med.rate2 = quantile(diff(as.numeric(start.timestamp)), .05)/med.t, med.h1 = median(h1), 
                                med.d = median(delta), med.sub.d = median(sub.delta), lost.sig.num = sum( pmax( round( diff(as.numeric(start.timestamp) ) / med.t ) -1 ,0)),
                                lost.sig.rate =  lost.sig.num*100/(sum+lost.sig.num) )
          
          if (nrow(lump_summary) != 1) {
            
            lump_eff.searching.time <- pmin(wnc_max.hr.gap*3600, (as.numeric(lump_summary$lump.start) - as.numeric(c(min(data$timestamp) ,lump_summary$lump.end[-nrow(lump_summary)]) ) ) )
          } else {
            
            lump_eff.searching.time <- pmin(wnc_max.hr.gap*3600, (as.numeric(lump_summary$lump.start) - as.numeric(min(data$timestamp) ) ) ) 
          }
          lump_eff.start <- warming.lump.min_gap.minute* 60 < lump_eff.searching.time
          lump_summary <- data.frame(lump_summary, searching.time = lump_eff.searching.time, eff.start = lump_eff.start)
          
          print(lump_summary)
          eff.lump_summary <- subset(lump_summary, eff.start == T)
          
          eff.cooking_info <- mapply(function(s,t) { z <- subset(s.pattern.cooking, start.timestamp %within% interval(s-dseconds(t),s))
          if (nrow(z) != 0) return(z[which.max(z$est.Wh),]) else return(z) },
          eff.lump_summary$lump.start, eff.lump_summary$searching.time, SIMPLIFY = F)
          
          cooking_eff.lump.idx <- which(sapply(eff.cooking_info, nrow) != 0)
          
          if (length(cooking_eff.lump.idx) != 0) {
            
            eff.cooking_info <- rbind.fill(eff.cooking_info)
            #             wnc_gap.minute <- (as.numeric(eff.lump_summary$lump.start[cooking_eff.lump.idx]) - as.numeric(eff.cooking_info[,'start.timestamp']) )/60 
            #             eff.cooking_info <- cbind(eff.cooking_info, time_gap = wnc_gap.minute)
            stored_lump.log[[w_idx]] <- lump_log.total
            stored_lump.summary[[w_idx]] <- lump_summary
            stored_eff.cooking_info[[w_idx]] <- eff.cooking_info
            stored_med_time[[w_idx]] <- tmp.med_time
            
            print(eff.lump_summary)
            print(eff.cooking_info)
          }
        }
      }
      
      total_eff.cooking_info <- rbind.fill(stored_eff.cooking_info)
      
      if (length(total_eff.cooking_info) == 0) {
        
        cat("There is no candidate for COOKING signal \n")
        cat("If you are sure on the existence of rice cookers, please adjust the cooking signal power range set from ", cooking.min_watt ,"to ", cooking.max_watt ," watt. \n")
        return(json.result)
      } else {
        
        # remove duplicated candidate
        watt.ordered <- total_eff.cooking_info[duplicated(total_eff.cooking_info$start.idx) == F,]
        watt.ordered <- watt.ordered[order(watt.ordered$delta),] 
        watt_idx <- which(diff(watt.ordered$delta) >= cooking.cand_split.watt)
        
        if (length(watt_idx) != 0) {
          cat("There are", length(watt_idx)+1, "groups for cooking candidates." , "\n")
          cooking.watt_s.idx <- c(0, watt_idx) + 1
          cooking.watt_e.idx <- c(watt_idx, nrow(watt.ordered))
          
          cooking.group_med.watt <- mapply(function(s,e) median(watt.ordered$delta[s:e]),
                                           cooking.watt_s.idx, cooking.watt_e.idx)
          
          chosen_cooking.cand.idx <- which.min(abs(cooking.group_med.watt-cooking.med_watt))
          chosen_cooking.cand <- watt.ordered[cooking.watt_s.idx[chosen_cooking.cand.idx]:cooking.watt_e.idx[chosen_cooking.cand.idx],]
          
        } else {
          
          print("There is no ambiguity in choosing cooking candidates.")
          chosen_cooking.cand <- watt.ordered
        }
        
        # refine cooking information
        tmp_med.sub.delta <- median(chosen_cooking.cand$sub.delta)
        tmp_med.delta <- median(chosen_cooking.cand$delta)
        tmp_med.est.fluc.num <- median(chosen_cooking.cand$est.fluc.num)
        
        tmp_med.est.on.sec <- median(chosen_cooking.cand$est.on.sec)
        tmp_min.est.on.sec <- min(chosen_cooking.cand$est.on.sec)
        
        tmp_s.pattern <- subset(s.pattern, sub.delta >= tmp_med.sub.delta - r.sub.delta_margin & 
                                  sub.delta <= tmp_med.sub.delta + r.sub.delta_margin )
        
        refined_s.pattern.cooking <- cooking.candidate.search(data, start.pattern = tmp_s.pattern, min_watt = (tmp_med.delta - r.delta_margin), max_watt = (tmp_med.delta + r.delta_margin), 
                                                              min_t.minute = 0, 
                                                              max_t.minute = min(cooking.max_t.minute, (tmp_med.est.on.sec/60) + r.cooking.minute_margin), 
                                                              min_fluc.num = 0)
        
        if (nrow(refined_s.pattern.cooking) == 0) {
          
          print("There are ambiguities in finding reasonable COOKING signals: please input more data so we can label the rice cooker in a reliable (i.e., statistical) way.")
        } else {
          
          # recalculation of 'lump summary': step 1) w/ refined cooking s.pattern
          for (w_idx in 1:length(stored_lump.summary)) {
            if ( !is.null(stored_lump.summary[[w_idx]]) ) {
              
              lump_summary <- stored_lump.summary[[w_idx]]
              chosen.s.info <- stored_lump.log[[w_idx]]
              eff.lump_summary <- subset(lump_summary, eff.start == T)
              
              eff.cooking_info <- mapply(function(s,t) { z <- subset(refined_s.pattern.cooking, start.timestamp %within% interval(s-dseconds(t),s))
              if (nrow(z) != 0) return(z[which.max(z$est.Wh),]) else return(z) },
              eff.lump_summary$lump.start, eff.lump_summary$searching.time, SIMPLIFY = F)
              
              cooking_eff.lump.idx <- which(sapply(eff.cooking_info, nrow) != 0)
              
              # recalculation of 'lump summary': step 2) w/ refined time gap between warming & cooking (search again)
              if (length(cooking_eff.lump.idx) != 0) {
                eff.cooking_info <- rbind.fill(eff.cooking_info)
                wnc_gap.minute <- (as.numeric(eff.lump_summary$lump.start[cooking_eff.lump.idx]) - as.numeric(eff.cooking_info[,'start.timestamp']) )/60 
                eff.cooking_info <- cbind(eff.cooking_info, time_gap = wnc_gap.minute)
                tmp_med.time_gap <- median(eff.cooking_info$time_gap)
                
                if (nrow(lump_summary) != 1) {
                  
                  lump_summary$searching.time <- pmin((tmp_med.time_gap + r.time.gap.minute_margin)*60, (as.numeric(lump_summary$lump.start) - as.numeric(c(min(data$timestamp) ,lump_summary$lump.end[-nrow(lump_summary)]) ) ) )
                } else {
                  
                  lump_summary$searching.time <- pmin((tmp_med.time_gap + r.time.gap.minute_margin)*60, (as.numeric(lump_summary$lump.start) - as.numeric(min(data$timestamp) ) ) ) 
                }
                
                lump_summary$eff.start <- min(cooking.max_t.minute*60, tmp_med.est.on.sec + r.cooking.minute_margin*60) < lump_summary$searching.time
                eff.lump_summary <- subset(lump_summary, eff.start == T)
                
                eff.cooking_info <- mapply(function(s,t) { z <- subset(refined_s.pattern.cooking, start.timestamp %within% interval(s-dseconds(t),s))
                if (nrow(z) != 0) return(z[which.max(z$est.Wh),]) else return(z) },
                eff.lump_summary$lump.start, eff.lump_summary$searching.time, SIMPLIFY = F)
                
                cooking_eff.lump.idx <- which(sapply(eff.cooking_info, nrow) != 0)
                warming_eff.lump.idx <- which(sapply(eff.cooking_info, nrow) == 0)
                
                if (length(cooking_eff.lump.idx) != 0) {
                  
                  eff.cooking_info <- rbind.fill(eff.cooking_info)
                  wnc_gap.minute <- (as.numeric(eff.lump_summary$lump.start[cooking_eff.lump.idx]) - as.numeric(eff.cooking_info[,'start.timestamp']) )/60 
                  eff.cooking_info <- cbind(eff.cooking_info, time_gap = wnc_gap.minute)
                  
                  print(eff.lump_summary)
                  print(eff.cooking_info)
                  
                  # refine cooking information
                  tmp_med.sub.delta <- median(eff.cooking_info$sub.delta)
                  tmp_med.delta <- median(eff.cooking_info$delta)
                  tmp_med.est.fluc.num <- median(eff.cooking_info$est.fluc.num)
                  tmp_med.time_gap <- median(eff.cooking_info$time_gap)
                  
                  tmp_med.est.on.sec <- median(eff.cooking_info$est.on.sec)
                  tmp_min.est.on.sec <- min(eff.cooking_info$est.on.sec)
                  
                  # energy computation
                  usage_info <- energyEstimation_ricecooker(data, pattern = chosen.s.info, threshold = thres_ap.h)
                  
                  if (length(usage_info) != 0){
                    warming.esti.sec <- usage_info[1]
                    warming.esti.watt <- usage_info[2]
                  } else {
                    warming.esti.sec <- 0
                    warming.esti.watt <- 0
                  }
                  
                  # computation for json information
                  
                  if (cooking.min_t.minute*60 <= tmp_med.est.on.sec) {
                    
                    json.candidate[[length(json.candidate)+1]] <- data.frame(cand_idx = w_idx, cooking_num = length(cooking_eff.lump.idx), warming_num = length(warming_eff.lump.idx),
                                                                             total_sig.num = sum(lump_summary$sum),
                                                                             ap.h1.min = min(chosen.s.info$h1), ap.h1.max = max(chosen.s.info$h1), ap.h1.med = median(chosen.s.info$h1),
                                                                             rp.delta.med = median(chosen.s.info$sub.delta), min.t = median(lump_summary$min.t), med.t = stored_med_time[[w_idx]],
                                                                             min.med.rate2 = median(lump_summary$min.med.rate2), usage_pwr_med = median(lump_summary$med.d), 
                                                                             usage_pwr_max = max(lump_summary$med.d), esti_usage.sec = warming.esti.sec, esti_usage.watt = warming.esti.watt,
                                                                             c.rp.med_delta = tmp_med.sub.delta, c.ap.med_delta = tmp_med.delta, c.ap.med_fluc.num = tmp_med.est.fluc.num,
                                                                             c.med_time.gap = tmp_med.time_gap, c.med_cooking.time = tmp_med.est.on.sec, c.min_cooking.time = tmp_min.est.on.sec)
                    
                  } else {
                    
                    print("Detected cooking information is not reasonable.")
                  }
                }
              }
            }
          }
        }
      }
      
      
      #       for (w_idx in 1:nrow(s.list)) {
      #         
      #             
      #             # refine cooking information
      #             tmp_med.sub.delta <- median(eff.cooking_info$sub.delta)
      #             tmp_med.delta <- median(eff.cooking_info$delta)
      #             tmp_med.est.fluc.num <- median(eff.cooking_info$est.fluc.num)
      #             tmp_med.time_gap <- median(eff.cooking_info$time_gap)
      #             
      #             tmp_med.est.on.sec <- median(eff.cooking_info$est.on.sec)
      #             tmp_min.est.on.sec <- min(eff.cooking_info$est.on.sec)
      #             
      #             print(data.frame(length(cooking_eff.lump.idx), length(warming_eff.lump.idx), tmp_med.sub.delta,
      #                              tmp_med.delta, tmp_med.est.on.sec, tmp_min.est.on.sec, 
      #                              tmp_med.est.fluc.num, tmp_med.time_gap))
      #             
      #             tmp_s.pattern <- subset(s.pattern, sub.delta >= tmp_med.sub.delta - r.sub.delta_margin & 
      #                                       sub.delta <= tmp_med.sub.delta + r.sub.delta_margin )
      #             refined_s.pattern.cooking <- cooking.candidate.search(data, start.pattern = tmp_s.pattern, min_watt = (tmp_med.delta - r.delta_margin), max_watt = (tmp_med.delta + r.delta_margin), 
      #                                                                   min_t.minute = 0, 
      #                                                                   max_t.minute = min(cooking.max_t.minute, (tmp_med.est.on.sec/60) + r.cooking.minute_margin), 
      #                                                                   min_fluc.num = 0)
      #             
      #             if (nrow(refined_s.pattern.cooking) == 0) {
      #               print("There are ambiguities in finding reasonable cooking signals.")
      #               
      #             } else {
      #               
      #               # recalculation of 'lump summary'
      #               if (nrow(lump_summary) != 1) {
      #                 
      #                 lump_summary$searching.time <- pmin((tmp_med.time_gap + r.time.gap.minute_margin)*60, (as.numeric(lump_summary$lump.start) - as.numeric(c(min(data$timestamp) ,lump_summary$lump.end[-nrow(lump_summary)]) ) ) )
      #               } else {
      #                 
      #                 lump_summary$searching.time <- pmin((tmp_med.time_gap + r.time.gap.minute_margin)*60, (as.numeric(lump_summary$lump.start) - as.numeric(min(data$timestamp) ) ) ) 
      #               }
      #               
      #               lump_summary$eff.start <- min(cooking.max_t.minute*60, tmp_med.est.on.sec + r.cooking.minute_margin*60) < lump_summary$searching.time
      #               eff.lump_summary <- subset(lump_summary, eff.start == T)
      #               
      #               eff.cooking_info <- mapply(function(s,t) { z <- subset(refined_s.pattern.cooking, start.timestamp %within% interval(s-dseconds(t),s))
      #                                                          if (nrow(z) != 0) return(z[which.max(z$est.Wh),]) else return(z) },
      #                                          eff.lump_summary$lump.start, eff.lump_summary$searching.time, SIMPLIFY = F)
      #               
      #               cooking_eff.lump.idx <- which(sapply(eff.cooking_info, nrow) != 0)
      #               warming_eff.lump.idx <- which(sapply(eff.cooking_info, nrow) == 0) 
      #               
      #               if (length(cooking_eff.lump.idx) != 0) {
      #                 
      #                 eff.cooking_info <- rbind.fill(eff.cooking_info)
      #                 wnc_gap.minute <- (as.numeric(eff.lump_summary$lump.start[cooking_eff.lump.idx]) - as.numeric(eff.cooking_info[,'start.timestamp']) )/60 
      #                 eff.cooking_info <- cbind(eff.cooking_info, time_gap = wnc_gap.minute)
      #                 
      #                 print(eff.lump_summary)
      #                 print(eff.cooking_info)
      #                 
      #                 # refine cooking information
      #                 tmp_med.sub.delta <- median(eff.cooking_info$sub.delta)
      #                 tmp_med.delta <- median(eff.cooking_info$delta)
      #                 tmp_med.est.fluc.num <- median(eff.cooking_info$est.fluc.num)
      #                 tmp_med.time_gap <- median(eff.cooking_info$time_gap)
      #                 
      #                 tmp_med.est.on.sec <- median(eff.cooking_info$est.on.sec)
      #                 tmp_min.est.on.sec <- min(eff.cooking_info$est.on.sec)
      #                 
      #                 # computation for json information
      #                 
      #                 if (cooking.min_t.minute*60 <= tmp_med.est.on.sec) {
      #                   
      #                   json.candidate[[length(json.candidate)+1]] <- data.frame(cand_idx = w_idx, cooking_num = length(cooking_eff.lump.idx), warming_num = length(warming_eff.lump.idx),
      #                                                                            total_sig.num = sum(lump_summary$sum),
      #                                                                            ap.h1.min = min(chosen.s.info$h1), ap.h1.max = max(chosen.s.info$h1), ap.h1.med = median(chosen.s.info$h1),
      #                                                                            rp.delta.med = median(chosen.s.info$sub.delta), min.t = median(lump_summary$min.t) ,med.t = tmp.med_time,
      #                                                                            min.med.rate2 = median(lump_summary$min.med.rate2), usage_pwr_med = median(lump_summary$med.d), 
      #                                                                            usage_pwr_max = max(lump_summary$med.d), 
      #                                                                            c.rp.med_delta = tmp_med.sub.delta, c.ap.med_delta = tmp_med.delta, c.ap.med_fluc.num = tmp_med.est.fluc.num,
      #                                                                            c.med_time.gap = tmp_med.time_gap, c.med_cooking.time = tmp_med.est.on.sec, c.min_cooking.time = tmp_min.est.on.sec)
      #                   
      #                 } else {
      #                   
      #                   print("Detected cooking information is not reasonable.")
      #                 }
      #                 
      #                 
      #                 
      #               }
      #               
      #             }
      #             
      #           }
      #           
      #         }
      #       }
      
      
      # make JSON meta file 
      if (length(json.candidate) != 0){
        
        json.candidate.list <- rbind.fill(json.candidate)
        
        print(json.candidate.list)
        
        max.cooking.num <- max(json.candidate.list$cooking_num)
        
        js <- subset(json.candidate.list, cooking_num == max.cooking.num)
        
        if ( nrow(js) > 1 ) {
          js <- js[which.max(js$total_sig.num),]
        }
        
        general.json.info <- c('cooking_num' = js$cooking_num, 'warming_num' = js$warming_num)
        
        warming.json.info <- c('eff_sample.num' = js$total_sig.num, 'ap.h1.min' = js$ap.h1.min, 'ap.h1.max' = js$ap.h1.max, 'ap.h1.med' = js$ap.h1.med,
                               'rp.delta.med' = js$rp.delta.med, 'min.t' = js$min.t, 'med.t' = js$med.t, 'min.med.rate2' = js$min.med.rate2,
                               'usage_pwr_med' = js$usage_pwr_med, 'usage_pwr_max' = js$usage_pwr_max, 'esti_usage.sec' = js$esti_usage.sec, 'esti_usage.watt' = js$esti_usage.watt)
        
        cooking.json.info <- c('c.rp.med_delta' = js$c.rp.med_delta, 'c.ap.med_delta' = js$c.ap.med_delta, 'c.ap.med_fluc.num' = js$c.ap.med_fluc.num,
                               'c.med_time.gap' = js$c.med_time.gap, 'c.med_cooking.time' = js$c.med_cooking.time, 'c.min_cooking.time' = js$c.min_cooking.time)
        
        meta.parameters <- c('eff_size' = eff_size, 'periodicity' = periodicity, 'thres_ap.h' = thres_ap.h, 'thres_rp.delta' = thres_rp.delta,
                             'search_iter' = search_iter, 'warming.min_minute' = warming.min_minute, 'warming.lump.min_gap.minute' = warming.lump.min_gap.minute,
                             'warming.sec_margin' = warming.sec_margin, 'wnc_max.hr.gap' = wnc_max.hr.gap, 'cooking.min_watt' = cooking.min_watt,
                             'cooking.max_watt' = cooking.max_watt, 'cooking.min_t.minute' = cooking.min_t.minute, 'cooking.min_fluctuation.num' = cooking.min_fluctuation.num,
                             'cooking.max_t.minute' = cooking.max_t.minute, 'r.sub.delta_margin' = r.sub.delta_margin, 'r.delta_margin' = r.delta_margin,
                             'r.time.gap.minute_margin' = r.time.gap.minute_margin, 'r.cooking.minute_margin' = r.cooking.minute_margin)
        
        json.result <- list(`meta-version` = 1, shape_type = "ricecooker_pattern_scan", general_info = general.json.info,
                            warming_info = warming.json.info,
                            cooking_info = cooking.json.info,
                            parameters = meta.parameters,
                            generation_info = list(data_used = list(start = str.t, end = end.t, sampling = 1), 
                                                   computed = as.character(Sys.time())) )
      } else {
        
        print("There is no candidate for rice cooker.")
      }
    }
  }
  
  return(json.result)
}

meta2PatternScan.ricecooker_1Hz <- function (data, meta, usage.pwr.adjust = 1.5, compensation_min.minute = 4) {
  
  # parameters
  str.t <- as.character(min(data$timestamp))
  end.t <- as.character(max(data$timestamp))
  answer.log <- data.frame( timestamp = seq(floor_date(min(data$timestamp), unit = "second"), 
                                            floor_date(max(data$timestamp), unit = "second"), 'secs'))
  answer.log <- data.frame( answer.log, p= rep(0,nrow(answer.log)), q= rep(0,nrow(answer.log)))
  
  '%nin%'<- Negate('%in%')
  
  # meta$warming_info['']
  ap.h1.min <- meta$warming_info['ap.h1.min']
  ap.h1.max <- meta$warming_info['ap.h1.max']
  meta$warming_info['ap.h1.med']
  meta$warming_info['rp.delta.med']
  min.t <- meta$warming_info['min.t']
  w.med.t <- meta$warming_info['med.t']
  meta$warming_info['min.med.rate2']
  usage_pwr_med <- meta$warming_info['usage_pwr_med']
  usage_pwr_max <- meta$warming_info['usage_pwr_max'] 
  
  esti_usage.sec <- meta$warming_info['esti_usage.sec']
  esti_usage.watt <- meta$warming_info['esti_usage.watt']
  
  # meta$cooking_info['']
  c.rp.med_delta <- meta$cooking_info['c.rp.med_delta']
  c.ap.med_delta <- meta$cooking_info['c.ap.med_delta']
  c.med_time.gap <- meta$cooking_info['c.med_time.gap']
  c.med_cooking.time <- meta$cooking_info['c.med_cooking.time']
  
  
  # meta$parameters['']
  eff_size <- meta$parameters['eff_size']
  meta$parameters['periodicity']
  thres_ap.h <- meta$parameters['thres_ap.h']
  thres_rp.delta <- meta$parameters['thres_rp.delta']
  warming.min_minute <- meta$parameters['warming.min_minute']
  #  warming.lump.min_gap.minute <- meta$parameters['warming.lump.min_gap.minute']
  warming.sec_margin <- meta$parameters['warming.sec_margin']
  #   meta$parameters['']
  #   meta$parameters['']
  r.sub.delta_margin <- meta$parameters['r.sub.delta_margin']
  r.delta_margin <- meta$parameters['r.delta_margin']
  cooking.max_t.minute <- meta$parameters['cooking.max_t.minute']
  r.time.gap.minute_margin <- meta$parameters['r.time.gap.minute_margin']
  #   meta$parameters['']
  #   meta$parameters['']
  
  # examine raw data
  data <- data[order(data$timestamp),] 
  
  s.pattern <- DetectPattern_1Hz_new_modifiedforRicecooker(data, position = "start", main_type = "active", sub_type = "reactive")
  s.pattern <- s.pattern[order(s.pattern$start.idx),] 
  
  # medium-power signals for warming
  s.pattern.warming1 <- subset(s.pattern, (h1 >= ap.h1.min) & (h1 <= ap.h1.max) & (abs(sub.delta) <= thres_rp.delta) & !is.na(min.slope) ) # original set
  s.pattern.warming2 <- subset(s.pattern, (h1 >= ap.h1.min) & (h1 <= ap.h1.max) & is.na(min.slope) ) # added set
  
  s.pattern.warming <- rbind(s.pattern.warming1, s.pattern.warming2)
  
  if (nrow(s.pattern.warming) < eff_size){
    
    stop("There's no signal for warming mode.")
  } else {
    
    chosen.s.info <- s.pattern.warming[order(s.pattern.warming$start.idx),] 
    lump.idx <- c(0, which(diff(as.numeric(chosen.s.info$start.timestamp)) >= warming.min_minute*60 ), nrow(chosen.s.info))
    chosen.lump <- which(diff(lump.idx) >= eff_size)
    
    if (length(chosen.lump)  == 0) {
      
      stop("There's no lump for warming mode.")
    } else {
      
      lump_log <- list()
      
      # examine each lump
      for (l_idx in 1:length(chosen.lump)) {
        
        tmp.start.idx <- lump.idx[chosen.lump[l_idx]] +1
        tmp.end.idx <- lump.idx[chosen.lump[l_idx]+1]
        
        lump_log[[length(lump_log)+1]] <- data.frame(chosen.s.info[tmp.start.idx:tmp.end.idx,], lump_idx = l_idx )
      }
      
      lump_log.total <- rbind.fill(lump_log) 
      
      lump_summary <- ddply(lump_log.total, .(lump_idx), summarize, sum = length(start.timestamp), med.t = median(diff(as.numeric(start.timestamp))) )
      
      lump_summary <- subset(lump_summary, med.t >= (w.med.t - warming.sec_margin) & 
                               med.t <= (w.med.t + warming.sec_margin) )
      
      if (nrow(lump_summary) == 0) {
        
        stop("Not enough value for warming.sec_margin.")
      } else {
        
        lump_log.total <- rbind.fill(lump_log[lump_summary$lump_idx])
        
        # insert warming signals (for results)
        new_timestamp <- floor_date(lump_log.total$start.timestamp, unit = "second")
        
        warming.start.idx <- which(answer.log$timestamp %in% new_timestamp)
        if (round(esti_usage.sec) != 0){
          warming.on.idx <- unique(unlist(lapply( warming.start.idx, function(x) x + 0:(round(esti_usage.sec)-1) )))
        } else {
          print("Warming energy estimation is not valid.")
          warming.on.idx <- unique(unlist(lapply( warming.start.idx, function(x) x + 0:floor(min.t))))
        }
        
        ### avoid overflow of the idx
        warming.on.idx <- warming.on.idx[warming.on.idx <= nrow(answer.log)] 
        
        if (round(esti_usage.sec) != 0){
          
          warming.usage_pwr <- esti_usage.watt
        } else {
          
          if (usage_pwr_med < 0) {
            warming.usage_pwr <- usage_pwr_max
          } else {
            warming.usage_pwr <- (usage_pwr_med + usage_pwr_max)/2
          }
        }
        
        answer.log$p[warming.on.idx] <- warming.usage_pwr * usage.pwr.adjust
        # end 
        
        lump_summary <- ddply(lump_log.total, .(lump_idx), summarize, sum = length(start.timestamp), lump.start = min(start.timestamp), lump.end = max(end.timestamp), lump.duration = as.numeric(lump.end) - as.numeric(lump.start),
                              min.t = min(diff(as.numeric(start.timestamp))), med.t = median(diff(as.numeric(start.timestamp))), min.med.rate2 = quantile(diff(as.numeric(start.timestamp)), .05)/med.t, med.h1 = median(h1), 
                              med.d = median(delta), med.sub.d = median(sub.delta), lost.sig.num = sum( pmax( round( diff(as.numeric(start.timestamp) ) / med.t ) -1 ,0)),
                              lost.sig.rate =  lost.sig.num*100/(sum+lost.sig.num) )
        
        if (nrow(lump_summary) != 1) {
          
          lump_searching.time <- pmin((c.med_time.gap + r.time.gap.minute_margin)*60, (as.numeric(lump_summary$lump.start) - as.numeric(c(min(data$timestamp) ,lump_summary$lump.end[-nrow(lump_summary)]) ) ) )
        } else {
          
          lump_searching.time <- pmin((c.med_time.gap + r.time.gap.minute_margin)*60, (as.numeric(lump_summary$lump.start) - as.numeric(min(data$timestamp) ) ) ) 
        }
        
        lump_eff.start <- cooking.max_t.minute*60 < lump_searching.time
        lump_summary <- data.frame(lump_summary, searching.time = lump_searching.time, eff.start = lump_eff.start)
        
        print(lump_summary)
        
        eff.lump_summary <- subset(lump_summary, eff.start == T)
        
        if (nrow(eff.lump_summary) == 0) {
          
          print("Not enough lumps for searching cooking signals")
        } else {
          
          # cooking signal computation
          cooking_s.pattern <- subset(s.pattern, sub.delta >= c.rp.med_delta - r.sub.delta_margin & 
                                        sub.delta <= c.rp.med_delta + r.sub.delta_margin )
          s.pattern.cooking <- cooking.candidate.search(data, start.pattern = cooking_s.pattern, min_watt = (c.ap.med_delta - r.delta_margin), max_watt = (c.ap.med_delta + r.delta_margin), 
                                                        min_t.minute = 0, 
                                                        max_t.minute = cooking.max_t.minute, 
                                                        min_fluc.num = 0)
          
          eff.cooking_info <- mapply(function(s,t) { z <- subset(s.pattern.cooking, start.timestamp %within% interval(s-dseconds(t),s))
          if (nrow(z) != 0) return(z[which.max(z$est.Wh),]) else return(z) },
          eff.lump_summary$lump.start, eff.lump_summary$searching.time, SIMPLIFY = F)
          
          cooking_eff.lump.idx <- which(sapply(eff.cooking_info, nrow) != 0)
          warming_eff.lump.idx <- which(sapply(eff.cooking_info, nrow) == 0) 
          
          print(eff.lump_summary)
          
          if (length(cooking_eff.lump.idx) != 0) {
            
            eff.cooking_info <- rbind.fill(eff.cooking_info)
            wnc_gap.minute <- (as.numeric(eff.lump_summary$lump.start[cooking_eff.lump.idx]) - as.numeric(eff.cooking_info[,'start.timestamp']) )/60 
            eff.cooking_info <- cbind(eff.cooking_info, time_gap = wnc_gap.minute)
            print(eff.cooking_info)
            
            # insert cooking signals (for results)
            cooking.start.timestamp <- floor_date(eff.cooking_info$start.timestamp, unit = "second")
            cooking.start.idx <- which(answer.log$timestamp %in% cooking.start.timestamp)
            cooking.on.idx <- unique(unlist(lapply( cooking.start.idx, function(x) x + 0:floor(c.med_cooking.time))))
            ### avoid overflow of the idx
            cooking.on.idx <- cooking.on.idx[cooking.on.idx <= nrow(answer.log)]
            answer.log$p[cooking.on.idx] <- c.ap.med_delta
            # end
            
            # cooking signal compensation
            cooking.lump_start.idx <- c(0, which(diff(as.numeric(s.pattern.cooking$start.timestamp)) > cooking.max_t.minute*60 )) + 1
            cooking.lump.start.log <- s.pattern.cooking[cooking.lump_start.idx,]
            
            detected.start.idx <- mapply(function(s) { z <- subset(cooking.lump.start.log, start.timestamp %within% interval(s-dminutes(cooking.max_t.minute),s+dminutes(cooking.max_t.minute) ) )
            return(z) }, eff.cooking_info$start.timestamp, SIMPLIFY = F)
            detected.start.idx <- rbind.fill(detected.start.idx)
            
            print("compensated cooking mode:")
            cooking_compensated.start.log <- cooking.lump.start.log[which(cooking.lump.start.log$start.idx %nin% detected.start.idx$start.idx),]
            
          } else {
            # cooking signal compensation
            cooking.lump_start.idx <- c(0, which(diff(as.numeric(s.pattern.cooking$start.timestamp)) > cooking.max_t.minute*60 )) + 1
            cooking.lump.start.log <- s.pattern.cooking[cooking.lump_start.idx,]
            
            print("compensated cooking mode:")
            cooking_compensated.start.log <- cooking.lump.start.log
          }
          
          
          
          cooking_compensated.start.log <- subset(cooking_compensated.start.log, est.on.sec >= compensation_min.minute*60 )
          
          print(cooking_compensated.start.log)
          
          if (nrow(cooking_compensated.start.log) != 0) {
            
            # insert cooking signals (for results)
            cooking.start.timestamp <- floor_date(cooking_compensated.start.log$start.timestamp, unit = "second")
            cooking.start.idx <- which(answer.log$timestamp %in% cooking.start.timestamp)
            cooking.on.idx <- unique(unlist(mapply( function(x,d) x + 0:floor(d), cooking.start.idx, pmin(cooking_compensated.start.log$est.on.sec,c.med_cooking.time))))
            
            
            ### avoid overflow of the idx
            cooking.on.idx <- cooking.on.idx[cooking.on.idx <= nrow(answer.log)]
            answer.log$p[cooking.on.idx] <- c.ap.med_delta
            # end
            
          }
          
        }
        
      }
      
    }
    
  }
  
  return(answer.log)
  
}

DetectGroup_15Hz_1D <- function(data, resolution, p_factor, group_size){
  
  logSummary <- list()
  logDetail <- list()
  ordered.h <- data
  
  r_idx <- 1
  iter_idx <- 1
  while( iter_idx <= resolution ){
    
    # print(nrow(ordered.delta))
    # for debug
    if ( nrow(ordered.h) +1 <= r_idx ){
      print("Resolution increment for searcing groups has stopped..")
      break
    }
    
    # examine delta
    ordered.h <- ordered.h[order(ordered.h$h1),]
    
    # examine h
    ordered.h <- ordered.h[order(ordered.h$h1),]
    
    ### detect group idx (i.e., wall for each group)
    h.diff <- data.frame( diff.h = diff(ordered.h$h1), ordered.idx = seq(1, nrow(ordered.h)-1) )
    ordered.h.diff <- h.diff[order(h.diff$diff.h, decreasing = TRUE),]
    wall.idx <- ordered.h.diff$ordered.idx[1:r_idx]
    wall.idx <- wall.idx[order(wall.idx)]
    
    ### identify group 1
    g1 <- cut( seq(1, nrow(ordered.h)), c(0, wall.idx, nrow(ordered.h)) ,labels= FALSE ) -1
    ordered.h <- cbind(ordered.h, g1)
    ordered.h <- ordered.h[order(ordered.h$start.idx), ]
    
    # summary for each group
    
    group.info <- ddply(ordered.h, .(g1), transform, tmp_g.sum = length(g1))
    
    ### exclude the info from isolated elements
    tmp_small.group <- subset(group.info, tmp_g.sum < group_size)
    r_idx <- r_idx -nrow( ddply(tmp_small.group, .(g1), summarize, tmp_sum = 'del') )
    if(r_idx < 1 ){r_idx <- 1}
    
    ordered.h <- subset(group.info, tmp_g.sum >= group_size)
    group.info <- ddply(ordered.h, .(g1), summarize, sum = length(g1), min.t = min(diff(as.numeric(start.timestamp))), med.t = median(diff(as.numeric(start.timestamp))), 
                        min.med.rate = min.t/med.t, min.med.rate2 = quantile(diff(as.numeric(start.timestamp)), .05)/med.t, med.h1 = median(h1),  med.d = median(delta), med.sub.d = median(sub.delta), lost.sig.num = sum( pmax( round( diff(as.numeric(start.timestamp) ) / med.t ) -1 ,0)), 
                        lost.sig.rate =  lost.sig.num*100/(sum+lost.sig.num) )
    
    ### effective group (conservative search by default)
    if (nrow(group.info) > 0){
      
      eff_group.info <- subset(group.info, (min.med.rate2 >= p_factor) & !(g1 == 0) ) 
      
      if(nrow(eff_group.info) >0){
        
        logSummary[[length(logSummary)+1]] <- eff_group.info
        
        for(g_idx in 1:nrow(eff_group.info) ){
          
          logDetail[[length(logDetail) +1]] <- ordered.h[(ordered.h$g1 == eff_group.info$g1[g_idx]), ]
          logDetail[[length(logDetail)]]$g1 <- NULL
          logDetail[[length(logDetail)]]$tmp_g.sum <- NULL
          
          ordered.h <- ordered.h[!(ordered.h$g1 == eff_group.info$g1[g_idx]) , ]
        }
      }
      
      # index increment for while loop
      r_idx <- r_idx -nrow(eff_group.info) +1
      if(r_idx < 1 ){r_idx <- 1}
    } else {
      
      r_idx <- r_idx + 1
    }
    
    iter_idx <- iter_idx + 1
    ordered.h$g1 <- NULL
    ordered.h$tmp_g.sum <- NULL
  }
  
  # return information
  if (length(logSummary) != 0) {
    logDetail[[length(logDetail) +1]] <- rbind.fill(logSummary)
    return(logDetail)
  } else {
    return(list())
  }
  
}

DetectGroup_1Hz_onedim <- function(data, resolution, p_factor, group_size){
  
  logSummary <- list()
  logDetail <- list()
  ordered.delta <- data
  
  r_idx <- 1
  iter_idx <- 1
  while( iter_idx <= resolution ){
    
    # print(nrow(ordered.delta))
    # for debug
    if ( nrow(ordered.delta) +1 <= r_idx ){
      print("Resolution has been reduced..")
      break
    }
    
    # examine delta
    ordered.delta <- ordered.delta[order(ordered.delta$delta),]
    
    ### detect group idx (i.e., wall for each group)
    delta.diff <- data.frame( diff.delta = diff(ordered.delta$delta), ordered.idx = seq(1, nrow(ordered.delta)-1) )
    ordered.delta.diff <- delta.diff[order(delta.diff$diff.delta, decreasing = TRUE),]
    wall.idx <- ordered.delta.diff$ordered.idx[1:r_idx]
    wall.idx <- wall.idx[order(wall.idx)]
    
    ### identify group 1
    g1 <- cut( seq(1, nrow(ordered.delta)), c(0, wall.idx, nrow(ordered.delta)) ,labels= FALSE ) -1
    ordered.delta <- cbind(ordered.delta, g1)
    ordered.delta <- ordered.delta[order(ordered.delta$start.idx), ]
    # summary for each group
    
    group.info <- ddply(ordered.delta, .(g1), transform, tmp_g.sum = length(g1))
    
    ### exclude the info from isolated elements
    tmp_small.group <- subset(group.info, tmp_g.sum < group_size)
    r_idx <- r_idx -nrow( ddply(tmp_small.group, .(g1), summarize, tmp_sum = 'del') )
    if(r_idx < 1 ){r_idx <- 1}
    
    ordered.delta <- subset(group.info, tmp_g.sum >= group_size)
    group.info <- ddply(ordered.delta, .(g1), summarize, sum = length(g1), min.t = min(diff(as.numeric(start.timestamp))), med.t = median(diff(as.numeric(start.timestamp))), 
                        min.med.rate = min.t/med.t, min.med.rate2 = quantile(diff(as.numeric(start.timestamp)), .05)/med.t, med.d = median(delta), med.sub.d = median(sub.delta), lost.sig.num = sum( pmax( round( diff(as.numeric(start.timestamp) ) / med.t ) -1 ,0)), 
                        lost.sig.rate =  lost.sig.num*100/(sum+lost.sig.num) )
    
    ### effective group (conservative search by default)
    if (nrow(group.info) > 0){
      
      eff_group.info <- subset(group.info, (min.med.rate >= p_factor) & !(g1 == 0) ) 
      
      if(nrow(eff_group.info) >0){
        
        logSummary[[length(logSummary)+1]] <- eff_group.info
        
        for(g_idx in 1:nrow(eff_group.info) ){
          
          logDetail[[length(logDetail) +1]] <- ordered.delta[(ordered.delta$g1 == eff_group.info$g1[g_idx]), ]
          
          ordered.delta <- ordered.delta[!(ordered.delta$g1 == eff_group.info$g1[g_idx]) , ]
        }
      }
      
      # index increment for while loop
      r_idx <- r_idx -nrow(eff_group.info) +1
      if(r_idx < 1 ){r_idx <- 1}
    } else {
      
      r_idx <- r_idx + 1
    }
    
    iter_idx <- iter_idx + 1
    ordered.delta$g1 <- NULL
    ordered.delta$tmp_g.sum <- NULL
  }
  
  # return information
  if (length(logSummary) != 0) {
    logDetail[[length(logDetail) +1]] <- rbind.fill(logSummary)
    return(logDetail)
  } else {
    return(list())
  }
  
}

#============================================================================================
# no restriction on delta and sub.delta !!!
DetectPattern_1Hz_new_modifiedforRicecooker <- function ( data, position = c("start", "end")
                                                          , main_type = c("reactive", "active")
                                                          , sub_type = c("active", "reactive")
                                                          , c_factor = 0
                                                          , debug.mode = F ){
  
  mainLog <- switch( main_type, 
                     'reactive' = data.frame( timestamp = data$timestamp, value = data$reactive_power), 
                     'active' = data.frame( timestamp = data$timestamp, value = data$active_power) )
  subLog <- switch( sub_type, 
                    'reactive' = data.frame( timestamp = data$timestamp, value = data$reactive_power), 
                    'active' = data.frame( timestamp = data$timestamp, value = data$active_power) )
  
  # for debug
  if ( nrow(mainLog) != nrow(subLog) ){
    cat("Log mismatch between active and reactive power!", nrow(mainLog), " and ", nrow(subLog), "\n")
    stop("Error")
  }
  
  slope <- get_speed_new(mainLog$timestamp, mainLog$value) 
  state <- scan_state_new(slope) 
  united.state <- stateCompression( state )
  
  edgeType <- match.arg(position)
  if ( edgeType == "start"){
    
    rising.edge.pattern <- list( c(1,2,3,4), c(1,3,4), c(1,2,3,1), c(1,3,1) )
    resultant1 <- ldply( rising.edge.pattern, 
                         function( pattern ){ patternIdx <- compressedPatternMatching_RC( united.state, pattern )
                         get_patternFeature_RC( mainLog, subLog, slope, patternIdx )} )
    
    rising.edge.pattern <- list(  c(1,2), c(1,3) ) 
    resultant2 <- ldply( rising.edge.pattern, 
                         function( pattern ){ patternIdx <- compressedPatternMatching_RC( united.state, pattern )
                         get_patternFeature_RC( mainLog, subLog, slope, patternIdx )} )
    resultant2 <- subset( resultant2, !(start.idx %in% resultant1$start.idx))
    if( nrow(resultant2) > 0 ) resultant1 <- rbind.fill( resultant1, resultant2 )
    
    resultant <- resultant1
    if( is.null(resultant) ) stop('There is no proper rising edge')
    
    if(debug.mode){
      par(mfrow=c(2,1), oma=c(4, 4, 4, 2.5), mar=rep(.1, 4), cex=1, las=1)
      plot(x=data$timestamp, y=data$active_power, ann=FALSE, xaxt="n", type='l')
      abline( v=resultant$start.timestamp, col='red' ) 
      plot(x=data$timestamp, y=data$reactive_power, ann=FALSE, xaxt="n", type='l')
      title(paste('Step1 : rising edge detection 결과\n', min(data$timestamp), '--', max(data$timestamp)), 
            outer=TRUE)
      mtext("Timestamp", 1, 1, outer=TRUE)
      mtext("Reactive / Active power", 2, 3, outer=TRUE, las=0)
      par(mfrow=c(1,1))
    }
    return( resultant )
    
  }else if (edgeType == "end"){
    
    falling.edge.pattern <- list( c(3,4), c(3,1), c(3,2) )
    resultant <- ldply( falling.edge.pattern, 
                        function( pattern ){ patternIdx <- compressedPatternMatching_RC( united.state, pattern )
                        get_patternFeature_RC( mainLog, subLog, slope, patternIdx, c_factor )} )
    if( is.null(resultant) ) stop('There is no proper falling edge')
    
    if(debug.mode){
      par(mfrow=c(2,1), oma=c(4, 4, 4, 2.5), mar=rep(.1, 4), cex=1, las=1)
      plot(x=data$timestamp, y=data$active_power, ann=FALSE, xaxt="n", type='l')
      abline( v=resultant$start.timestamp, col='blue' ) 
      plot(x=data$timestamp, y=data$reactive_power, ann=FALSE, xaxt="n", type='l')
      title(paste('Step1 : falling edge detection 결과\n', min(data$timestamp), '--', max(data$timestamp)), 
            outer=TRUE)
      mtext("Timestamp", 1, 1, outer=TRUE)
      mtext("Reactive / Active power", 2, 3, outer=TRUE, las=0)
      par(mfrow=c(1,1))
    }
    
    resultant[,sapply(resultant, is.numeric)] <- abs(resultant[,sapply(resultant, is.numeric)])
    return( resultant )
  }
  
}

compressedPatternMatching_RC <- function( compressedState, targetPattern ){
  
  pattern.length <- length(targetPattern) 
  
  if( targetPattern[1] %in% c(1,2) ){ # rising edge
    
    if( any( targetPattern %in% c(3,4) & shift(targetPattern,-1) %in% c(1,2) ) ){
      # power가 증가 -> 감소 -> 증가로 정의되면 마지막 증가는 패턴에서 제외
      pattern.length <- max(which(targetPattern %in% c(3,4) & shift(targetPattern,-1) %in% c(1,2) ))
    }
    
    matchedPattern.str <- grepl.pattern( compressedState$val, targetPattern )
    matchedPattern.end <- matchedPattern.str + pattern.length - 1
    maxSlope.pos <- matchedPattern.str + which( targetPattern == 1 & shift(targetPattern,-1) %in% c(2,3)) - 1
    minSlope.pos <- matchedPattern.str + which( targetPattern == 3 & shift(targetPattern,-1) %in% c(4,1)) - 1 
    peak.pos <- matchedPattern.str + which( targetPattern %in% c(1,2) & shift(targetPattern,-1) %in% c(3,4)) - 1
    
    result <- data.frame(str = compressedState$str[ matchedPattern.str ], 
                         end = compressedState$end[ matchedPattern.end ])
    
    if( length(maxSlope.pos) != 0 ) result <- cbind( result, data.frame(maxSlope = compressedState$end[ maxSlope.pos ]))
    if( length(minSlope.pos) != 0 ) result <- cbind( result, data.frame(minSlope = compressedState$end[ minSlope.pos ]))
    if( length(peak.pos) == 0 ) peak.pos <- matchedPattern.end
    
    result <- cbind( result, data.frame(peak = compressedState$end[ peak.pos ] + 1)) 
    return( result )
    
  }else if( targetPattern[1] %in% c(3,4) ){ # falling edge 
    
    matchedPattern.str <- grepl.pattern( compressedState$val, targetPattern )
    matchedPattern.end <- matchedPattern.str + pattern.length - 1
    minSlope.pos <- matchedPattern.str + which( targetPattern == 3 & shift(targetPattern,-1) %in% c(4,1,2)) - 1 
    peak.pos <- matchedPattern.str 
    
    return( data.frame(str = compressedState$str[ matchedPattern.str ], 
                       end = compressedState$end[ matchedPattern.end ],
                       minSlope = compressedState$end[ minSlope.pos ],
                       peak = compressedState$str[ peak.pos ]))
  }
}

#============================================================================================
# h1 : peak - left (main)
# h2 : rite - peak (main)
# delta : rite - left = h1 + h2 (main) 
# sub.delta : rite - left (sub)
get_patternFeature_RC <- function(data, sub.data, speed, patternIndex, c_factor, c_flag = F){
  
  timestamp <- data$timestamp
  value <- data$value
  sub.value <- sub.data$value
  
  patternFeature <- patternIndex[,c('str','end')]
  patternFeature$len <- patternIndex$end - patternIndex$str + 1
  patternFeature$str.t <- timestamp[patternIndex$str ]
  patternFeature$end.t <- timestamp[patternIndex$end+1]
  
  if('maxSlope' %in% names(patternIndex)) patternFeature$max.slope <- speed[ patternIndex$maxSlope ]
  if('minSlope' %in% names(patternIndex)) patternFeature$min.slope <- speed[ patternIndex$minSlope ]
  
  if('peak' %in% names(patternIndex)){
    peak.value.set <- value[ patternIndex$peak ]
    patternFeature$h1 <- peak.value.set - value[ patternIndex$str ]
    patternFeature$h2 <- value[ patternIndex$end+1 ] - peak.value.set
  }
  
  
  patternFeature$sub.delta <- sub.value[patternIndex$end+1] - sub.value[patternIndex$str]
  patternFeature$delta <- value[patternIndex$end+1] - value[patternIndex$str]
  
  if( !missing(c_factor) && c_factor >= 1 ){
    
    patternFeature$org_h2 <- patternFeature$h2
    patternFeature$org_sub.delta <- patternFeature$sub.delta
    
    patternFeature <- subset( patternFeature, (str > c_factor*len) & (end < length(value)-c_factor*len) )
    if( nrow(patternFeature) == 0 ) return(NULL)
    
    if (c_flag == T) {
      
      consistency_flag <- rep(1, nrow(patternFeature))
      consistency_flag[ which(patternFeature$org_h2 > 0 | patternFeature$org_sub.delta > 0) ] <- 0
      
    }

    for(c_idx in 1:c_factor) {
      
      left.str <- patternFeature$str - patternFeature$len * c_idx
      left.end <- patternFeature$str - patternFeature$len * (c_idx-1) - 1
      rite.str <- patternFeature$end + patternFeature$len * (c_idx-1) + 2
      rite.end <- patternFeature$end + patternFeature$len * c_idx + 1
      
      tmp_sign_delta <- mapply( function(ls,le,rs,re) mean(value[rs:re]) - mean(value[ls:le]),
                                left.str, left.end, rite.str, rite.end )
      
      tmp_sign_sub.delta <- mapply( function(ls,le,rs,re) mean(sub.value[rs:re]) - mean(sub.value[ls:le]), 
                                    left.str, left.end, rite.str, rite.end)
      
      if (c_flag == T) {
        consistency_flag[ which(tmp_sign_delta > 0 | tmp_sign_sub.delta > 0) ] <- 0
      }
      
      patternFeature$h2 <- patternFeature$h2 + tmp_sign_delta
      patternFeature$delta <- patternFeature$delta + tmp_sign_delta
      patternFeature$sub.delta <- patternFeature$sub.delta + tmp_sign_sub.delta
      
    }
    
    if (c_flag == T) {
      patternFeature <- patternFeature[which(consistency_flag == 1),]
    }
    
    patternFeature$h2 <- patternFeature$h2 / (c_factor+1)
    patternFeature$delta <- patternFeature$delta / (c_factor+1)
    patternFeature$sub.delta <- patternFeature$sub.delta / (c_factor+1) 
  }
  names(patternFeature) <- mapvalues( names(patternFeature), warn_missing=F, 
                                      c('str','end','len','str.t','end.t'), 
                                      c('start.idx','end.idx','pattern.size',
                                        'start.timestamp','end.timestamp') )
  
  return(patternFeature)
}

cooking.candidate.search <- function(data, start.pattern, min_watt, max_watt, min_t.minute, max_t.minute, min_fluc.num) {
  
  s.pattern.cooking <- subset(start.pattern, delta >= min_watt & delta <= max_watt)
  
  if ( nrow(s.pattern.cooking) == 0 ) {
    print("There is no candidate for cooking signals")
    return(s.pattern.cooking)
  } else {
    
    s.pattern.cooking_actual.center.ap <- apply(s.pattern.cooking, 1, function(x) ((data$active_power[as.numeric(x['start.idx'])] +  
                                                                                      data$active_power[as.numeric(x['end.idx'])]   )/2) )
    
    s.pattern.cooking <- data.frame(s.pattern.cooking, center.ap = s.pattern.cooking_actual.center.ap)
    
    #         s.pattern.cooking_eff.time.period <- apply(s.pattern.cooking, 1, function(x) { z <- subset(data[as.numeric(x['end.idx']):(as.numeric(x['end.idx'])+cooking.max_t.minute*60),],
    #                                                                                                    active_power < as.numeric(x['center.ap']))
    #                                                                                        if (nrow(z) != 0) return(min(z$timestamp)) else return(data$timestamp[(as.numeric(x['end.idx'])+cooking.max_t.minute*60)]) })
    
    s.pattern.cooking_eff.energy <- data.matrix( mapply(function(t,p,d) {z <- subset(data, timestamp %within% interval(t, t+dminutes(max_t.minute) ) &
                                                                                       active_power > p ) 
    num <- nrow(z)
    return(c(num, num*d ))}, s.pattern.cooking$end.timestamp, s.pattern.cooking$center.ap, s.pattern.cooking$delta ) ) 
    
    s.pattern.cooking_fluc.num <- mapply( function(e) {z <- subset(s.pattern.cooking, start.timestamp %within% interval(e, e+dminutes(max_t.minute) ) )
    return(nrow(z))}, s.pattern.cooking$end.timestamp)
    
    s.pattern.cooking <- data.frame(s.pattern.cooking, # time.on.sec = as.numeric(s.pattern.cooking_eff.time.period) - as.numeric(s.pattern.cooking$end.timestamp),
                                    est.on.sec = s.pattern.cooking_eff.energy[1,], est.Wh = s.pattern.cooking_eff.energy[2,]/3600, est.fluc.num = s.pattern.cooking_fluc.num)
    
    s.pattern.cooking <- subset(s.pattern.cooking, (est.on.sec >= min_t.minute*60) & (est.fluc.num >= min_fluc.num))
    
    #     s.pattern.cooking_eff.fluc.num <- apply(s.pattern.cooking_naive, 1, function(x) { z <- subset(s.pattern.cooking_naive, start.timestamp.numeric >= as.numeric(x['start.timestamp.numeric']) &
    #                                                                                                     start.timestamp.numeric <= (as.numeric(x['start.timestamp.numeric'])+1800))
    #                                                                                       
    #                                                                                       return(nrow(z)) })
    
    #           apply(s.pattern.cooking, 1, function(x) { z <- subset(data[as.numeric(x['end.idx']):(as.numeric(x['end.idx'])+cooking.max_t.minute*60),],
    #                                                                                               active_power > as.numeric(x['center.ap'])) 
    #                                                                                   return(nrow(z))} )
    #         
    #         cooking.max.watt <- t(data.matrix( mapply(function(s,t) { z <- subset(s.pattern.cooking, start.timestamp %within% interval(s-dseconds(t),s))
    #                                                                   if (nrow(z) != 0) return(z[which.max(z$delta),]) else return(z) },
    #                                                                   lump_summary$lump.start, lump_summary$searching.time) ))
    
    return(s.pattern.cooking)
    
  }
  
}

cooking.candidate.search_15Hz <- function(data, start.pattern, min_watt, max_watt, min_t.minute, max_t.minute, min_fluc.num, Hertz = 15) {
  
  s.pattern.cooking <- subset(start.pattern, delta >= min_watt & delta <= max_watt)
  
  if ( nrow(s.pattern.cooking) == 0 ) {
    print("There is no candidate for cooking signals")
    return(s.pattern.cooking)
  } else {
    
    s.pattern.cooking_actual.center.ap <- apply(s.pattern.cooking, 1, function(x) ((data$active_power[as.numeric(x['start.idx'])] +  
                                                                                      data$active_power[as.numeric(x['end.idx'])]   )/2) )
    
    s.pattern.cooking <- data.frame(s.pattern.cooking, center.ap = s.pattern.cooking_actual.center.ap)
    
    #         s.pattern.cooking_eff.time.period <- apply(s.pattern.cooking, 1, function(x) { z <- subset(data[as.numeric(x['end.idx']):(as.numeric(x['end.idx'])+cooking.max_t.minute*60),],
    #                                                                                                    active_power < as.numeric(x['center.ap']))
    #                                                                                        if (nrow(z) != 0) return(min(z$timestamp)) else return(data$timestamp[(as.numeric(x['end.idx'])+cooking.max_t.minute*60)]) })
    
    s.pattern.cooking_eff.energy <- data.matrix( mapply(function(t,p,d) {z <- subset(data, timestamp %within% interval(t, t+dminutes(max_t.minute) ) &
                                                                                       active_power > p ) 
    num <- nrow(z) / Hertz
    return(c(num, num*d ))}, s.pattern.cooking$end.timestamp, s.pattern.cooking$center.ap, s.pattern.cooking$delta ) ) 
    
    s.pattern.cooking_fluc.num <- mapply( function(e) {z <- subset(s.pattern.cooking, start.timestamp %within% interval(e, e+dminutes(max_t.minute) ) )
    return(nrow(z))}, s.pattern.cooking$end.timestamp)
    
    s.pattern.cooking <- data.frame(s.pattern.cooking, # time.on.sec = as.numeric(s.pattern.cooking_eff.time.period) - as.numeric(s.pattern.cooking$end.timestamp),
                                    est.on.sec = s.pattern.cooking_eff.energy[1,], est.Wh = s.pattern.cooking_eff.energy[2,]/3600, est.fluc.num = s.pattern.cooking_fluc.num)
    
    s.pattern.cooking <- subset(s.pattern.cooking, (est.on.sec >= min_t.minute*60) & (est.fluc.num >= min_fluc.num))
    
    #     s.pattern.cooking_eff.fluc.num <- apply(s.pattern.cooking_naive, 1, function(x) { z <- subset(s.pattern.cooking_naive, start.timestamp.numeric >= as.numeric(x['start.timestamp.numeric']) &
    #                                                                                                     start.timestamp.numeric <= (as.numeric(x['start.timestamp.numeric'])+1800))
    #                                                                                       
    #                                                                                       return(nrow(z)) })
    
    #           apply(s.pattern.cooking, 1, function(x) { z <- subset(data[as.numeric(x['end.idx']):(as.numeric(x['end.idx'])+cooking.max_t.minute*60),],
    #                                                                                               active_power > as.numeric(x['center.ap'])) 
    #                                                                                   return(nrow(z))} )
    #         
    #         cooking.max.watt <- t(data.matrix( mapply(function(s,t) { z <- subset(s.pattern.cooking, start.timestamp %within% interval(s-dseconds(t),s))
    #                                                                   if (nrow(z) != 0) return(z[which.max(z$delta),]) else return(z) },
    #                                                                   lump_summary$lump.start, lump_summary$searching.time) ))
    
    return(s.pattern.cooking)
    
  }
  
}


energyEstimation_ricecooker <- function(data, pattern, threshold){
  
  o_pattern <- pattern[ order(pattern$start.idx), ]
  
  slot_length <- pmax(0, o_pattern$start.idx[-1] - o_pattern$end.idx[-nrow(o_pattern)])
  
  slot.idx_list <- mapply( function(s,eVec){c(s,eVec)}, as.list( o_pattern$start.idx[-nrow(o_pattern)] ), 
                           mapply( function(x,l) (x+c(0:l)), o_pattern$end.idx[-nrow(o_pattern)], slot_length) )
  
  chosen.slot.info <- lapply(slot.idx_list, function(x){ signal.diff <- data$active_power[x[-1]] - data$active_power[x[1]]
  if( any(abs(signal.diff) < threshold, na.rm=T)){
    loc <- min( which( abs(signal.diff) < threshold ))
    len <- x[-1][loc] - x[1] # +1 -1 
    W <- sum(pmax(0,data$active_power[x[1]:x[-1][loc]] - data$active_power[x[1]] ))/len
    return(data.frame(length = len, watt = W))
  }else return(NULL) } )
  
  if (length(chosen.slot.info[!sapply(chosen.slot.info, is.null )]) != 0) {
    chosen.slot.info <- rbind.fill(chosen.slot.info)
    return(c(median(chosen.slot.info$length), median(chosen.slot.info$watt)))
    
  } else {
    print("energy estimation for warming mode has failed.")
    return(c())
    
  }
  
}

#============================================================================================
#============================================================================================  
# < supplementary functions >
#============================================================================================
#============================================================================================

pattern.merge <- function (pattern.one, pattern.two) {
  
  merged.list <- rbind(pattern.one, pattern.two)
  merged.list <- merged.list[order(merged.list$start.timestamp),]
  time.diff <- diff(as.numeric(merged.list$start.timestamp))
  med.time <- median(time.diff)
  
  approx_lost.sig_num <- round( time.diff / med.time )
  temp.small.sig <- length( which( approx_lost.sig_num  == 0 ))
  approx_lost.sig_num <- sum(approx_lost.sig_num -1) + temp.small.sig
  
  sums <- nrow(merged.list)
  min_time.diff <- min(time.diff)
  med_time.diff <- med.time
  min.med_rate <- min_time.diff / med_time.diff
  min_time.diff2 <- quantile(time.diff, .05)
  min.med.rate2 <- min_time.diff2/med_time.diff
  approx_loss.rate_percent <- approx_lost.sig_num*100/(sums+approx_lost.sig_num)
  
  p.one.timestamp <- as.numeric(pattern.one$start.timestamp)
  p.two.timestamp <- as.numeric(pattern.two$start.timestamp)
  
  tmp_outer.calc <- outer(p.one.timestamp, p.two.timestamp, function(i,j) abs(i-j) )
  
  min.time.diff.of.two.patterns1 <- apply( tmp_outer.calc , 1, min )
  lower.quantile.patterns1 <- quantile(min.time.diff.of.two.patterns1, .05)
  med.quantile.patterns1 <- quantile(min.time.diff.of.two.patterns1, .5)
  upper.quantile.patterns1 <- quantile(min.time.diff.of.two.patterns1, .95)
  
  min.time.diff.of.two.patterns2 <- apply( tmp_outer.calc , 2, min )
  lower.quantile.patterns2 <- quantile(min.time.diff.of.two.patterns2, .05)
  med.quantile.patterns2 <- quantile(min.time.diff.of.two.patterns2, .5)
  upper.quantile.patterns2 <- quantile(min.time.diff.of.two.patterns2, .95)
  
  list.info <- data.frame( sums, min_time.diff, med_time.diff, min.med_rate, min.med.rate2, min_time.diff2,
                           approx_lost.sig_num, approx_loss.rate_percent,lower.quantile.patterns1, med.quantile.patterns1,
                           upper.quantile.patterns1, lower.quantile.patterns2, med.quantile.patterns2, upper.quantile.patterns2)
  # print(list.info)
  
  merged.output <- list()
  merged.output[[1]] <- merged.list
  merged.output[[2]] <- list.info
  
  return(merged.output)
  
}

