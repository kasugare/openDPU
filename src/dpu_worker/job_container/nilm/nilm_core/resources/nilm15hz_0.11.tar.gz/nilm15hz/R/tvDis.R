#' @title tvDis
#' @author CH
#' @description disaggregate TV from total data
#' @update 2015.12.03
#' @input c(timestamp, active_power, reactive_power)
#' @output c(timestamp, p, q) : tv timestamp, active_power, reactive_power
#' procedure : feature extraction -> classification -> reconstruction
#'

#source(file = 'tvFeatureExtractor.R')
#source(file = 'connectMethod.R')
#source(file = 'tvReconstructor.R')
#source(file="edgeDetector.R")
#source(file="cutBlocks.R")

library(stringr)
library(xgboost)
library(pracma)


# load trained classifier
# load("tvClassifier.rda")

xgboost.fit <- readRDS( "/home/nilm/CloudNilm/libs/tvClassifier.rds")

# Training Mode (Fit learning model)
generate.meta.tv <- function(X = NULL, ...){

  ###
  # dummy function
  # copied and modified from generate.meta.washer
  if(!is.data.frame(X)) {
    X <- as.data.frame(X)
  }
  #X <- tbl_df(X)

  # Get tuning parameters
  TVParas = JSONforTV(...)

  return(TVParas)
}


JSONforTV <- function( metaVer = 1, startTS = "2015-11-01 00:00:00", endTS ="2015-11-01 23:59:59",
                       computedTime = as.character(Sys.time())){
  ###
  # dummy function
  # copied and modified from washer

  resJSON = list()

  #####
  # META VERSION
  resJSON['meta-version'] = metaVer

  #####
  resJSON$shape_type <- "TV"

  resJSON$generation_info = list(
    data_used = list(
      start = startTS,
      end = endTS
    ),
    samplingRate = 15,
    computed = computedTime)

  #class(resJSON) <- c(class(resJSON), "WashingMachine")
  return(resJSON)

}

meta2tv <- function( data, meta  ){
  tvDis( data)
}

tvDis <- function(data){

  # simple preprocessing : time stamp
  timeStamp_original <- data[,1]
  timeStamp <- as.POSIXlt(data[,1], "%Y-%m-%d %H:%M:%OS8")
  timeStamp <- as.numeric(timeStamp)
  timeStamp <- (timeStamp - timeStamp[1])/3600
  data[,1] <- timeStamp
  colnames(data) <- c('timestamp', 'active_power', 'reactive_power')


  # parameters
  blockSize <- 15*60*5 #5minutes
  operationPoint <- 0.8 # tv On threshold, predicion>operationPoint -> On
  tvApValue <- 80 # tvOn : active power
  tvRpValue <- 0 # tvOn : reactive power
  connectThreshold <- 6 # 6*5 = 30min

  tvFeatures <- tvFeatureExtractor(data, blockSize)

  prediction <- predict(xgboost.fit, as.matrix(tvFeatures))
  prediction_connect30 <- connectMethod(prediction, operationPoint, 6)

  tv_disAp <- tvReconstructor(prediction_connect30, data, blockSize, tvApValue)
  tv_disRp <- rep(tvRpValue, length(tv_disAp))
  tvDisaggregated <- data.frame( timestamp = timeStamp_original,
                                 p = tv_disAp,
                                 q = tv_disRp)
  return( tvDisaggregated)
}



######################################################################################################################
#' @title connectMethod
#' @author CH
#' @description upper layer classification algorithm. if the distance between two On-states is shorter than threshold,
#'              connect On-state in a row.
#'              e.g. distanceThreshold 4
#'              0.85 0.5 0.4 0.9 0.5 0.2 -> 1 1 1 1 0.5 0.2
#'
#' @update 2015.12.03
#' @input predictValue : classification result probability
#'        operationPoint : decision threshold, prob>0.8 -> On
#'        distanceThreshold : the distance between two On-states threshold
#' @output modified classification vector





connectMethod <- function(predictValues, operationPoint, distanceThreshold){

  modifiedPredictValues <- predictValues;

  # On-state index list
  onList <- which(predictValues > operationPoint)

  if (length(onList)>0){
    for (i in 1:(length(onList)-1))
    {
      currentOn <- onList[i]
      nextOn <- onList[i+1]

      if ((nextOn-currentOn)<=distanceThreshold){
        modifiedPredictValues[currentOn:nextOn] <- 1
      } else{
        modifiedPredictValues[currentOn] <- 0

        if (i==(length(onList)-1)){ # last two block
          modifiedPredictValues[nextOn] <- 0
        }
      }

    }
  }

  return(modifiedPredictValues)
}

######################################################################################################################

#' @title cutBlocks
#' @author CH
#' @description cut block from sequence
#' @update 2015.12.03
#' @input ap, rp or ts sequence
#' @output block Table(floor(length(ap)/blockSize)*blockSize)
#'


cutBlocks <- function(ap, blockSize)
{

  blockTable = matrix(0, floor(length(ap)/blockSize), blockSize);
  for (i in 1:floor(length(ap)/blockSize)){
    blockTable[i,] = ap[(blockSize*(i-1)+1):(blockSize*i)];
  }

  return(blockTable)
}

######################################################################################################################

#' @title edgeDetector
#' @author (author) prof. / (interpreter) CH
#' @description interpreted version of MATLAB edgeDetector
#' @update 2015.12.01
#' @input the result of getDataFromCSV(ts, rp, ap, idx table)
#' @output transient vectors
#'         type : edge type, e.g. 1X -> rising edge, 2X -> falling edge, 3X-> impulse, -1 -> unknown
#'         startIndex : transient start index
#'         endIndex : transient end index
#'         endStartAp : steadystateHeightAp in old version, (Ap after transient - Ap before transient), for impulse check.
#'         endStartRp : steadystateHeightRp in old version, (Rp after transient - Rp before transient), for impulse check.
#'         maxStartAp : maximum Ap after the start of tranisent
#'         maxStartRp : maximum Rp after the start of tranisent#'
#'         mixStartAp : minimum Ap after the start of tranisent
#'         mixStartRp : minimum Rp after the start of tranisent
#'         numTransAp : the number of points that change Ap compared to (i-1)th point. e.g.) 1 1 3 ->1, 2 0 5 -> 2
#'         numSegmentsAp : the number of segments. e.g. RF -> 2, R->1, RFRRFR ->6
#'         maxSlopeAp : maximum Ap slope
#'         maxSlopeRp : maximum Rp slope
#'         minSlopeAp : minimum Ap slope
#'         minSlopeRp : minimum Rp slope
#'         edgeSequence : the sequence of edges in transient. e.g. RF, R, , RRF
#' @update 2015.12.01 : flatSectionList가 비어있는 경우 처리.



edgeDetectorTV <- function(data) {
  ##
  # EDGEDETECTOR Summary of this function goes here
  #
  # TODO: Rising edge should be modeled as an object (or strucutre or class
  # or a container depending on language in use)


  ## Handle sign errors of raw data. This can happen due to installation
  #  problem.

  colnames(data) <- c("ts", "ap", "rp")

  if (mean(data$ap) < 0) {
    data$ap <- -data$ap
  }
  if (mean(data$rp) < 0) {
    data$rp <- -data$rp
  }

  ## -------------------------------------------------------------
  # Define parameters
  SAMPLING_RATE <- 15 # 15Hz sampling
  UNIT_TIME <- 3600 # 1.0 in dataTs correspondes to 3600
  # s <- sprintf('SAMPLING_RATE = %d',SAMPLING_RATE)
  # print(s)
  # s <- sprintf('UNIT_TIME = %d seconds corredponds to 1.0 in dataTs',UNIT_TIME)
  # print(s)


  # Slope threshold to declare FLAT
  FLAT_SLOPE_THRESH <- 1 # Per sample (trainslates to 15W/sec)
  # Slope thrshold to declare
  RF_SLOPE_THRESH <- 7 # Per sample (translates to 105W/sec)

  # Min length to be flatSection
  FLAT_LENGTH_THRESH <- 7 # At least this number of samples

  # Max number of missing samples for evaluation
  MAX_MISS_SAMPLES_SECS <- 1 # Up to 1 sec of missing samples are ignored.
  # Max time allowed for 'consecutive missing samples' to be valid. Scale properly
  CONS_MISS_SAMPLES_MAXTIME_THRESH <- MAX_MISS_SAMPLES_SECS/UNIT_TIME


  # Impulse removal related
  MAX_IMP_LENGTH_SECS <- 20 # Upto 20seconds for an impulse
  IMP_TIME_THRESH <- MAX_IMP_LENGTH_SECS/UNIT_TIME

  SIM_POWER_LEVEL_MARGIN <- 3.0 # Similar power level margin
  POWER_DIFF_THRESH <- 10.0 # At least this much needed to declare an appliance on or off event

  # Transient classification related
  MIN_MAX_AP_THRESH <- 7.0 # At least this much of fluctuation needed to be considered as a transient
  GEN_EDGE_LENGTH_THRESH <- 3 # The length of generalized-edge needs to be at least as long as this value

  FR_FLAT_ADD_RATIO_THRESH <- 0.1 # Ratio of difference between left and right peaks of FR compared to impulse's height

  # tag types
  FLAT <- 0
  RISING <- 1
  FALLING <- -1
  UNKNOWN <- -99

  # Diff
  diffVecAp <- diff(data$ap, lag = 1)
  diffVecRp <- diff(data$rp, lag = 1)
  diffVecTs <- diff(data$ts, lag = 1)
  diffVecAp[length(diffVecAp)+1] <- 0 # zero-pad the last sample
  diffVecRp[length(diffVecRp)+1] <- 0 # zero-pad the last sample
  diffVecTs[length(diffVecTs)+1] <- 1/SAMPLING_RATE # Pad with a number
  ## -------------------------------------------------------------
  DATA_LENGTH <- dim(data)[1]
  ## Per sample tags
  tagsAp <- rep(1, DATA_LENGTH) * UNKNOWN
  tagsRp <- rep(1, DATA_LENGTH) * UNKNOWN



  tagsAp[abs(diffVecAp) <= FLAT_SLOPE_THRESH] <- FLAT
  tagsAp[diffVecAp <= -1*RF_SLOPE_THRESH] <- FALLING
  tagsAp[RF_SLOPE_THRESH <= diffVecAp] <- RISING

  tagsRp[abs(diffVecRp) <= FLAT_SLOPE_THRESH] <- FLAT
  tagsRp[diffVecRp <= (-1) * RF_SLOPE_THRESH] <- FALLING
  tagsRp[RF_SLOPE_THRESH <= diffVecRp] <- RISING


  # Deal with missing data samples
  tagsAp[CONS_MISS_SAMPLES_MAXTIME_THRESH < diffVecTs] <- UNKNOWN
  tagsRp[CONS_MISS_SAMPLES_MAXTIME_THRESH < diffVecTs] <- UNKNOWN


  ## -------------------------------------------------------------
  # Detect stable/absolutely FLAT sections

  # Mentality : try to detect short sections of stable FLAT's
  lengthTags <- length(tagsAp)

  # if length(tagsRp ~= lengthTags)
  #   error('Lengths of AP and RP do not match. Pre-processing error.')
  # end

  # Initialize
  NUM_ATTRIBUTES <- 4
  flatSectionList <- matrix(0,lengthTags, NUM_ATTRIBUTES)
  numFlatSections <- 0



  k <- 1
  while(1)
  {
    if (tagsAp[k]==FLAT && tagsRp[k]==FLAT) # Use AND rule: both AP and RP need to be FLAT
    {

      flatStartIndex <- k
      k <- k+1
      while (tagsAp[k] == FLAT && tagsRp[k] == FLAT)
      {
        k <- k+1
        if (k >= lengthTags)
        {
          break
        }
      }
      flatEndIndex <- k
      flatLength <- flatEndIndex - flatStartIndex
      flatStartPowerAp <- data$ap[flatStartIndex]

      # Chunk length only. Ignore power deviation as the flat section becomes large - very low slope everywhere, anyway
      if (flatLength >= FLAT_LENGTH_THRESH)
      {
        numFlatSections <- numFlatSections+1
        flatSectionList[numFlatSections,] <- c(flatStartIndex,flatEndIndex,flatLength,flatStartPowerAp)
      }
    }

    k <- k+1

    # Check if all done
    if (k >= length(data$ap))
    {
      break
    }
  }

  # Truncate
  flatSectionList = flatSectionList[1:numFlatSections,]

  ## -------------------------------------------------------------
  # Flat removal
  # Remove flat sections that are part of impulse

  keepList <- vector() # Keep the first flatSection
  keepList[1] <- 1

  if(numFlatSections>2){# 12.01 update : flatSectionList가 비어있는 경우 handling.
    for (k in 2:(nrow(flatSectionList)-1))
    {

      # condition 1 : Time-wise, prev and next flatSections are close enough
      # condition 2 : Power levels of prev and next flatSections are similar
      # condition 3 : Middle flatSection needs to be higher power

      if ((data$ts[flatSectionList[k+1,1]] - data$ts[flatSectionList[k-1,2]])< IMP_TIME_THRESH
          && abs(data$ap[flatSectionList[k+1,1]] - data$ap[flatSectionList[k-1,2]]) < SIM_POWER_LEVEL_MARGIN
          && POWER_DIFF_THRESH <= (min(data$ap[flatSectionList[k,1]:flatSectionList[k,2]]) - data$ap[flatSectionList[k-1,2]]))
      {
        # Do nothing. This will cause k'th flat section to be removed
      }
      else
      {
        keepList <- rbind(keepList, k)
      }
    }
  }

  keepList <- rbind(keepList, nrow(flatSectionList))
  # Remove flats inside of impulse shapes
  if (!is.null(nrow(flatSectionList))){
    flatSectionList <- flatSectionList[keepList,]
  }
  ####12.01 update start
  #keepList <- keepList[keepList>0]
  #if (nrow(flatSectionList) > 0){
  #  flatSectionList = unique(flatSectionList[which(keepList>0),])
  #}
  ####12.01 update end


  ## -------------------------------------------------------------
  # Flat addition
  # Add flat sections when between

  newFlat <- vector()
  if (!is.null(nrow(flatSectionList))){
    for (k in 1:(nrow(flatSectionList)-1))
    {
      # A genEdge
      startIndex <- flatSectionList[k,2] # [flatStartIndex flatEndIndex flatLength flatStartPowerAp]
      endIndex <- flatSectionList[k+1,1]
      genEdgeLength <- endIndex - startIndex + 1 # Transient

      # Vector to investigate
      dataApLocal <- data$ap[startIndex:endIndex]
      diffVecTsLocal <- diffVecTs[startIndex:endIndex-1]

      # Features
      maxAp <- max(dataApLocal)
      minAp <- min(dataApLocal)

      # Ignore if FLAT-like, too short, or too many missing data points
      if ((maxAp - minAp) < MIN_MAX_AP_THRESH || genEdgeLength < GEN_EDGE_LENGTH_THRESH)
      {
        next
      }

      # Create a summary table of FALLING and RISING streaks
      streakList <- data.frame()
      j <- startIndex

      while(1)
      {
        type <- tagsAp[j]
        sIndex <- j
        j <- j+1
        while (tagsAp[j] == type)
        {
          j <- j+1
          if(j>=endIndex)
          {
            break
          }
        }
        eIndex <- j

        if (type==FALLING || type == RISING)
        {
          streakList <- rbind(streakList, c(type, sIndex, eIndex, data$ap[sIndex], data$ap[eIndex]))
        }
        if (j >= endIndex)
        {
          break
        }
      }

      # Merge consecutive FALLING's and consecutive Rising's
      streakListMerged <- data.frame()
      if (2 <= nrow(streakList))
      {
        n <- 1
        while (1)
        {
          prevVec <- streakList[n,]
          n <- n+1
          if (nrow(streakList) < n)
          {
            break
          }
          while (prevVec[1] == streakList[n,1])
          {
            # merge
            prevVec[3] <- streakList[n,3]
            prevVec[5] <- streakList[n,5]
            n <- n+1
            if (nrow(streakList) < n)
            {
              break
            }
          }
          streakListMerged <- rbind(streakListMerged, prevVec)
          if (nrow(streakList) < n)
          {
            break
          }
        }
      }
      else
      {
        streakListMerged <- streakList
      }

      # Check if FALLING -> RISING happens
      # If a proper condition is met, add the min value point to the newFlat
      if (nrow(streakListMerged) > 1)
      {
        for (n in 1:(nrow(streakListMerged)-1))
        {
          if ((streakListMerged[n,1] == FALLING) && (streakListMerged[n+1,1] == RISING)
              && ((abs(streakListMerged[n,4] - streakListMerged[n+1,5]) <= SIM_POWER_LEVEL_MARGIN)
                  || (abs(streakListMerged[n,4] - streakListMerged[n+1,5]) <= (streakListMerged[n,4] - streakListMerged[n,5])*FR_FLAT_ADD_RATIO_THRESH)))
          {
            ind <- which.min(data$ap[streakListMerged[n,3]:streakListMerged[n+1,2]])
            newFlat <- rbind(newFlat, streakListMerged[n,3] + ind - 1)
          }
        }
      }
    }
  } else{#### 12.01 update start
    # flat section이 비어있는 경우 handling : 처음과 끝을 flat으로 놓음.
    # A genEdge
    startIndex <- 1 # [flatStartIndex flatEndIndex flatLength flatStartPowerAp]
    endIndex <- length(data$ts)
    genEdgeLength <- endIndex - startIndex + 1 # Transient

    # Vector to investigate
    dataApLocal <- data$ap[startIndex:endIndex]
    diffVecTsLocal <- diffVecTs[startIndex:(endIndex-1)]

    # Features
    maxAp <- max(dataApLocal)
    minAp <- min(dataApLocal)

    # Ignore if FLAT-like, too short, or too many missing data points
    if ((maxAp - minAp) < MIN_MAX_AP_THRESH || genEdgeLength < GEN_EDGE_LENGTH_THRESH){}

    # Create a summary table of FALLING and RISING streaks
    streakList <- data.frame()
    j <- startIndex

    while(1)
    {
      type <- tagsAp[j]
      sIndex <- j
      j <- j+1
      while (tagsAp[j] == type)
      {
        j <- j+1
        if(j>=endIndex)
        {
          break
        }
      }
      eIndex <- j

      if (type==FALLING || type == RISING)
      {
        streakList <- rbind(streakList, c(type, sIndex, eIndex, data$ap[sIndex], data$ap[eIndex]))
      }
      if (j >= endIndex)
      {
        break
      }
    }

    # Merge consecutive FALLING's and consecutive Rising's
    streakListMerged <- data.frame()
    if (2 <= nrow(streakList))
    {
      n <- 1
      while (1)
      {
        prevVec <- streakList[n,]
        n <- n+1
        if (nrow(streakList) < n)
        {
          break
        }
        while (prevVec[1] == streakList[n,1])
        {
          # merge
          prevVec[3] <- streakList[n,3]
          prevVec[5] <- streakList[n,5]
          n <- n+1
          if (nrow(streakList) < n)
          {
            break
          }
        }
        streakListMerged <- rbind(streakListMerged, prevVec)
        if (nrow(streakList) < n)
        {
          break
        }
      }
    }
    else
    {
      streakListMerged <- streakList
    }

    # Check if FALLING -> RISING happens
    # If a proper condition is met, add the min value point to the newFlat
    if (nrow(streakListMerged) > 1)
    {
      for (n in 1:(nrow(streakListMerged)-1))
      {
        if ((streakListMerged[n,1] == FALLING) && (streakListMerged[n+1,1] == RISING)
            && ((abs(streakListMerged[n,4] - streakListMerged[n+1,5]) <= SIM_POWER_LEVEL_MARGIN)
                || (abs(streakListMerged[n,4] - streakListMerged[n+1,5]) <= (streakListMerged[n,4] - streakListMerged[n,5])*FR_FLAT_ADD_RATIO_THRESH)))
        {
          ind <- which.min(data$ap[streakListMerged[n,3]:streakListMerged[n+1,2]])
          newFlat <- rbind(newFlat, streakListMerged[n,3] + ind - 1)
        }
      }
    }
  }
  ### 12.01 update end

  # Add the new flats (point-flats) to the list
  flatSectionListNew <- cbind(newFlat, newFlat, rep(1, length(newFlat)), data$ap[newFlat])
  flatSectionList <- rbind(flatSectionList, flatSectionListNew) # Merge
  flatSectionList <- flatSectionList[order(flatSectionList[,1]),]



  ## -------------------------------------------------------------
  # Classify generalized-edges between FLAT's


  # Initialize
  NUM_ATTRIBUTES <- 15


  if (!is.null(nrow(flatSectionList))){ # 12.01 update
    genEdgeList <- matrix(0, nrow(flatSectionList)-1, NUM_ATTRIBUTES )
    numEdges <- 0
    genEdgeStringList <- rep('', nrow(flatSectionList)-1)
    for (k in 1:(nrow(flatSectionList)-1))
    {
      previousFlatSection <- flatSectionList[k,] # [flatStartIndex flatEndIndex flatLength flatStartPowerAp]
      nextFlatSection <- flatSectionList[k+1,]

      startIndex <- previousFlatSection[2]
      endIndex <- nextFlatSection[1]
      genEdgeLength <- endIndex - startIndex + 1

      # Vector to investigate
      dataApLocal <- data$ap[startIndex:endIndex]
      diffVecTsLocal <- diffVecTs[startIndex:(endIndex-1)]



      # Features
      maxAp <- max(dataApLocal)
      minAp <- min(dataApLocal)

      # Ignore if FLAT-like, too short, or too many missing data points
      if ((maxAp - minAp) < MIN_MAX_AP_THRESH || genEdgeLength < GEN_EDGE_LENGTH_THRESH)
      {
        next
      }

      # Vector to investigate: additional
      diffVecApLocal <- diffVecAp[startIndex:(endIndex-1)]

      dataRpLocal <- data$rp[startIndex:endIndex]
      diffVecRpLocal <- diffVecRp[startIndex:(endIndex-1)]

      tagsApLocal <- tagsAp[startIndex:(endIndex-1)]
      tagsRpLocal <- tagsRp[startIndex:(endIndex-1)]

      #browser()

      # Features
      startAp <- dataApLocal[1]
      endAp <- dataApLocal[length(dataApLocal)]

      startRp <- dataRpLocal[1]
      endRp <- dataRpLocal[length(dataRpLocal)]
      maxRp <- max(dataRpLocal)
      minRp <- min(dataRpLocal)

      endStartAp <- endAp - startAp
      maxStartAp <- maxAp - startAp
      minStartAp <- minAp - startAp

      endStartRp <- endRp - startRp
      maxStartRp <- maxRp - startRp
      minStartRp <- minRp - startRp

      maxSlopeAp <- max(diffVecApLocal)
      minSlopeAp <- min(diffVecApLocal)

      maxSlopeRp <- max(diffVecRpLocal)
      minSlopeRp <- min(diffVecRpLocal)

      numTransAp <- sum(tagsApLocal[1:(length(tagsApLocal)-1)] != tagsApLocal[2:length(tagsApLocal)])
      numTransRp <- sum(tagsRpLocal[1:(length(tagsRpLocal)-1)] != tagsRpLocal[2:length(tagsRpLocal)])

      numSegmentsAp <- 0
      shapeAlphabet <- ''
      type <- 'U'
      for (j in 1:length(tagsApLocal))
      {
        if (tagsApLocal[j] == RISING)
        {
          if (type != 'R')
          {
            shapeAlphabet <- paste(shapeAlphabet, 'R', sep = "")
            numSegmentsAp <- numSegmentsAp + 1
            type <- 'R'
          }
        }
        else if (tagsApLocal[j] == FALLING)
        {
          if (type != 'F')
          {
            shapeAlphabet <- paste(shapeAlphabet, 'F', sep = "")
            numSegmentsAp <- numSegmentsAp + 1
            type <- 'F'
          }
        }
        else
        {
          type <- 'U'
        }


      }

      type <- -1



      if(strcmp(shapeAlphabet, 'R') && POWER_DIFF_THRESH < endStartAp)
      {
        # Simple R
        type <- 11
      }
      else if(strcmp(shapeAlphabet, 'RF') && POWER_DIFF_THRESH < endStartAp)
      {
        # 'R' with overshooting
        type <- 12
      }
      else if(strcmp(shapeAlphabet, 'F') && endStartAp < (-1)*POWER_DIFF_THRESH)
      {
        # Simple 'F'
        type <- 21
      }
      else if(strcmp(shapeAlphabet, 'RF') && abs(endStartAp)<=SIM_POWER_LEVEL_MARGIN)
      {
        # Simple impulse
        type <- 31
      }
      else if(strcmp(shapeAlphabet, 'RFF') && abs(endStartAp)<=SIM_POWER_LEVEL_MARGIN)
      {
        # RFF impulse
        type <- 32
      }
      else if(substr(shapeAlphabet,1,1)=='F' && abs(endStartAp)<=SIM_POWER_LEVEL_MARGIN) #12.01 update
      {
        # falling impulse
        type <- 33
      }
      else if(abs(endStartAp)<=SIM_POWER_LEVEL_MARGIN)
      {
        # Other impulses
        type <- 34
      }



      edgeInfo <- c(type, startIndex, endIndex, endStartAp, endStartRp, maxStartAp, maxStartRp, minStartAp, minStartRp,
                    numTransAp, numSegmentsAp, maxSlopeAp, maxSlopeRp, minSlopeAp, minSlopeRp)


      # Now update genEdgeList
      numEdges <- numEdges + 1
      genEdgeList[numEdges,] <- edgeInfo
      genEdgeStringList[numEdges] <- shapeAlphabet
    }
  } else{ #### 12.01 update start
    # flatSectionList가 비어있는 경우 handling : 처음과 끝을 flat으로 놓음.

    genEdgeList <- data.frame()
    numEdges <- 0
    genEdgeStringList <- data.frame()

    startIndex <- 1
    endIndex <- length(data$ts)
    genEdgeLength <- endIndex - startIndex + 1

    # Vector to investigate
    dataApLocal <- data$ap[startIndex:endIndex]
    diffVecTsLocal <- diffVecTs[startIndex:(endIndex-1)]



    # Features
    maxAp <- max(dataApLocal)
    minAp <- min(dataApLocal)

    # Ignore if FLAT-like, too short, or too many missing data points
    if (!((maxAp - minAp) < MIN_MAX_AP_THRESH)&&!(genEdgeLength < GEN_EDGE_LENGTH_THRESH)){

      # Vector to investigate: additional
      diffVecApLocal <- diffVecAp[startIndex:(endIndex-1)]

      dataRpLocal <- data$rp[startIndex:endIndex]
      diffVecRpLocal <- diffVecRp[startIndex:(endIndex-1)]

      tagsApLocal <- tagsAp[startIndex:(endIndex-1)]
      tagsRpLocal <- tagsRp[startIndex:(endIndex-1)]

      #browser()

      # Features
      startAp <- dataApLocal[1]
      endAp <- dataApLocal[length(dataApLocal)]

      startRp <- dataRpLocal[1]
      endRp <- dataRpLocal[length(dataRpLocal)]
      maxRp <- max(dataRpLocal)
      minRp <- min(dataRpLocal)

      endStartAp <- endAp - startAp
      maxStartAp <- maxAp - startAp
      minStartAp <- minAp - startAp

      endStartRp <- endRp - startRp
      maxStartRp <- maxRp - startRp
      minStartRp <- minRp - startRp

      maxSlopeAp <- max(diffVecApLocal)
      minSlopeAp <- min(diffVecApLocal)

      maxSlopeRp <- max(diffVecRpLocal)
      minSlopeRp <- min(diffVecRpLocal)

      numTransAp <- sum(tagsApLocal[1:(length(tagsApLocal)-1)] != tagsApLocal[2:length(tagsApLocal)])
      numTransRp <- sum(tagsRpLocal[1:(length(tagsRpLocal)-1)] != tagsRpLocal[2:length(tagsRpLocal)])

      numSegmentsAp <- 0
      shapeAlphabet <- ''
      type <- 'U'
      for (j in 1:length(tagsApLocal))
      {
        if (tagsApLocal[j] == RISING)
        {
          if (type != 'R')
          {
            shapeAlphabet <- paste(shapeAlphabet, 'R', sep = "")
            numSegmentsAp <- numSegmentsAp + 1
            type <- 'R'
          }
        }
        else if (tagsApLocal[j] == FALLING)
        {
          if (type != 'F')
          {
            shapeAlphabet <- paste(shapeAlphabet, 'F', sep = "")
            numSegmentsAp <- numSegmentsAp + 1
            type <- 'F'
          }
        }
        else
        {
          type <- 'U'
        }


      }

      type <- -1


      if(strcmp(shapeAlphabet, 'R') && POWER_DIFF_THRESH < endStartAp)
      {
        # Simple R
        type <- 11
      }
      else if(strcmp(shapeAlphabet, 'RF') && POWER_DIFF_THRESH < endStartAp)
      {
        # 'R' with overshooting
        type <- 12
      }
      else if(strcmp(shapeAlphabet, 'F') && endStartAp < (-1)*POWER_DIFF_THRESH)
      {
        # Simple 'F'
        type <- 21
      }
      else if(strcmp(shapeAlphabet, 'RF') && abs(endStartAp)<=SIM_POWER_LEVEL_MARGIN)
      {
        # Simple impulse
        type <- 31
      }
      else if(strcmp(shapeAlphabet, 'RFF') && abs(endStartAp)<=SIM_POWER_LEVEL_MARGIN)
      {
        # RFF impulse
        type <- 32
      }
      else if(substr(shapeAlphabet,1,1)=='F' && abs(endStartAp)<=SIM_POWER_LEVEL_MARGIN) #12.01 update
      {
        # falling impulse
        type <- 33
      }
      else if(abs(endStartAp)<=SIM_POWER_LEVEL_MARGIN)
      {
        # Other impulses
        type <- 34
      }


      edgeInfo <- c(type, startIndex, endIndex, endStartAp, endStartRp, maxStartAp, maxStartRp, minStartAp, minStartRp,
                    numTransAp, numSegmentsAp, maxSlopeAp, maxSlopeRp, minSlopeAp, minSlopeRp)


      # Now update genEdgeList
      numEdges <- numEdges + 1
      genEdgeList <- edgeInfo
      genEdgeStringList <-rbind(genEdgeStringList, shapeAlphabet)
    }
  }#### 12.01 update end

  # Truncate
  if ((!is.null(nrow(genEdgeList)))&&numEdges>0){
    genEdgeList <- as.data.frame(genEdgeList[1:numEdges,])
    if (numEdges==1){
      genEdgeList <- t(genEdgeList)
    }
    colnames(genEdgeList) <- c("type", "startIndex", "endIndex", "endStartAp", "endStartRp", "maxStartAp", "maxStartRp", "minStartAp", "minStartRp",
                               "numTransAp", "numSegmentsAp", "maxSlopeAp", "maxSlopeRp", "minSlopeAp", "minSlopeRp")
    genEdgeStringList <- as.data.frame(genEdgeStringList[1:numEdges])
    colnames(genEdgeStringList) <- "edgeString"
  } else if(numEdges==1){
    genEdgeList <- as.data.frame(t(genEdgeList))
    colnames(genEdgeList) <- c("type", "startIndex", "endIndex", "endStartAp", "endStartRp", "maxStartAp", "maxStartRp", "minStartAp", "minStartRp",
                               "numTransAp", "numSegmentsAp", "maxSlopeAp", "maxSlopeRp", "minSlopeAp", "minSlopeRp")
    genEdgeStringList <- as.data.frame(genEdgeStringList[1:numEdges])
    colnames(genEdgeStringList) <- "edgeString"
  } else{
    genEdgeList <- data.frame()
    genEdgeStringList <- data.frame()
  }


  # 12.01 update : flatSectionList error handling
  if (is.null(nrow(flatSectionList))){
    flatSectionList <- data.frame(t(flatSectionList))
  }

  if (flatSectionList[1,1]==0&&flatSectionList[1,2]==0&&flatSectionList[1,3]==0&&flatSectionList[1,1]==0){
    flatSectionList = flatSectionList[-1,]
  }

  if (is.null(nrow(flatSectionList))){
    flatSectionList <- data.frame(t(flatSectionList))
  }

  colnames(flatSectionList) <- c("flatStartIndex","flatEndIndex", "flatLength", "flatStartPowerAp")



  return(list("edgeList"=genEdgeList, "edgeStringList" = genEdgeStringList, "flatList" = flatSectionList))

  # 12.01 delete
  #edgeInfoTable <- cbind(genEdgeList, genEdgeStringList, flatSectionList)
  #colnames(edgeInfoTable) <- c("type", "startIndex", "endIndex", "endStartAp", "endStartRp", "maxStartAp", "maxStartRp", "minStartAp", "minStartRp",
  #                             "numTransAp", "numSegmentsAp", "maxSlopeAp", "maxSlopeRp", "minSlopeAp", "minSlopeRp", "edgeSequence", "flatStartIndex",
  #                             "flatEndIndex", "flatLength", "flatStartPowerAp")

  #return(edgeInfoTable)

}



######################################################################################################################


#' @title tvFeatureExtractor
#' @author CH
#' @description extract tv block features from total data
#' @update 2015.12.03
#' @input data : c(timestamp, active_power, reactive_power)
#'        blockSize : time block Size
#' @output features of data blocks


tvFeatureExtractor <- function(data, blockSize){


  total_ts <- data[,1]
  total_ap <- data[,2]
  total_rp <- data[,3]

  totalApBlock <- cutBlocks(total_ap, blockSize)
  totalRpBlock <- cutBlocks(total_rp, blockSize)
  totalTsBlock <- cutBlocks(total_ts, blockSize)



  # edge features
  type11NumList <- rep(0,nrow(totalApBlock)) # number of Simple R edges in the block
  type12NumList <- rep(0,nrow(totalApBlock)) # number of 'R' with overshooting in the block
  type21NumList <- rep(0,nrow(totalApBlock)) # number of Simple F edges in the block
  type22NumList <- rep(0,nrow(totalApBlock)) # TODO : delete it
  type31NumList <- rep(0,nrow(totalApBlock)) # number of simple impulse in the block
  type32NumList <- rep(0,nrow(totalApBlock)) # number of RFF impulse in the block
  type33NumList <- rep(0,nrow(totalApBlock)) # number of falling impulse in the block
  type34NumList <- rep(0,nrow(totalApBlock)) # number of other impulse in the block

  edgeNumList <- rep(0,nrow(totalApBlock)) # numer of edges
  maxSlopeMeanList <- rep(0,nrow(totalApBlock)) # mean maxSlope of edges in the block
  maxSlopeVarList <- rep(0,nrow(totalApBlock)) # var maxSlope of edges in the block
  minSlopeMeanList <- rep(0,nrow(totalApBlock)) # mean minSlope of edges in the block
  minSlopeVarList <- rep(0,nrow(totalApBlock)) # var min Slope of edges in the block

  stringLengthMaxList <- rep(0,nrow(totalApBlock)) # max edge string length
  stringLengthMeanList <- rep(0,nrow(totalApBlock)) # mean edge string length
  stringLengthVarList <- rep(0,nrow(totalApBlock)) # var edge string length

  # additional edge features
  smallRisingNumList <- rep(0,nrow(totalApBlock)) # number of edges(maxSlope<40)
  smallFallingNumList <- rep(0,nrow(totalApBlock)) # number of edges(minSlope>-40)
  largeImpulseNumList <- rep(0,nrow(totalApBlock)) # number of edges(max slope > 100 & impulse)

  # ap features
  medianMinDiffList <- rep(0,nrow(totalApBlock)) # median(blockAp)-min(blockAp)
  quantile1MinDiffList <- rep(0,nrow(totalApBlock)) # quantile(blockAp, 0.25) - min(blockAp)
  meanLargerThanMedianList <- rep(0,nrow(totalApBlock)) # mean>median? (logical)

  # 7 diff(0.5 second diff) features
  diff7MeanList <- rep(0,nrow(totalApBlock)) #7 diff mean
  diff7VarList <- rep(0,nrow(totalApBlock)) #7 diff var
  diff7SmallCountList <- rep(0,nrow(totalApBlock)) # number of 7diff(<15)
  diff7LargeCountList <- rep(0,nrow(totalApBlock)) # number of 7diff(>30&<60)

  # 30 diff (2 second diff) features
  diff30MeanList <- rep(0,nrow(totalApBlock)) #30 diff mean
  diff30VarList <- rep(0,nrow(totalApBlock)) #30diff var
  diff30SmallCountList <- rep(0,nrow(totalApBlock)) # number of 30diff(<15)
  diff30LargeCountList <- rep(0,nrow(totalApBlock)) # number of 30diff(>30&<60)

  # flat features
  flatDiffVarList <- rep(0,nrow(totalApBlock)) # var of flat diff in the block
  flatLengthVarList <- rep(0,nrow(totalApBlock)) # var of flat length in the block
  flatNumList <- rep(0,nrow(totalApBlock)) # flat number in the block



  for (i in 1:nrow(totalApBlock)){
    blockTs <- totalTsBlock[i,]
    blockAp <- totalApBlock[i,]
    blockRp <- totalRpBlock[i,]

    dataBlock <- data.frame(cbind(blockTs, blockAp, blockRp))
    colnames(dataBlock) <- c("ts","ap","rp")
    edgeDetectorResult <- edgeDetectorTV(dataBlock)
    edgeList <- edgeDetectorResult[[1]]
    edgeStringList <- edgeDetectorResult[[2]]
    flatList <- edgeDetectorResult[[3]]

    if (nrow(edgeStringList)>1){
      stringLengthMax <- max(apply(edgeStringList, MARGIN=1,FUN = nchar))
      stringLengthMean <- mean(apply(edgeStringList, MARGIN=1,FUN = nchar))
      stringLengthVar <- var(apply(edgeStringList, MARGIN=1,FUN = nchar))
    } else if(nrow(edgeStringList)==1){
      stringLengthMax <- apply(edgeStringList, MARGIN = 1, FUN = nchar)
      stringLengthMean <- apply(edgeStringList, MARGIN = 1, FUN = nchar)
      stringLengthVar <- 0
    } else{
      stringLengthMax <- 0
      stringLengthMean <- 0
      stringLengthVar <- 0
    }

    stringLengthMaxList[i] <- stringLengthMax
    stringLengthMeanList[i] <- stringLengthMean
    stringLengthVarList[i] <- stringLengthVar
    ## edge statistics features
    # type count
    if (nrow(edgeList)>0){
      type11NumList[i] <- sum(edgeList[,1]==11)
      type12NumList[i] <- sum(edgeList[,1]==12)
      type21NumList[i] <- sum(edgeList[,1]==21)
      type22NumList[i] <- sum(edgeList[,1]==22)
      type31NumList[i] <- sum(edgeList[,1]==31)
      type32NumList[i] <- sum(edgeList[,1]==32)
      type33NumList[i] <- sum(edgeList[,1]==33)
      type34NumList[i] <- sum(edgeList[,1]==34)
    } else{
      type11NumList[i] <- 0
      type12NumList[i] <- 0
      type21NumList[i] <- 0
      type22NumList[i] <- 0
      type31NumList[i] <- 0
      type32NumList[i] <- 0
      type33NumList[i] <- 0
      type34NumList[i] <- 0
    }

    edgeNumList[i] = nrow(edgeList)

    if (edgeNumList[i] > 1){
      maxSlopeMeanList[i] <- mean(edgeList[,6])
      maxSlopeVarList[i] <- var(edgeList[,6])
      minSlopeMeanList[i] <- mean(edgeList[,8])
      minSlopeVarList[i] <- var(edgeList[,8])
      smallRisingNumList[i] <- sum(edgeList[,6]>0 & edgeList[,6]<40)
      smallFallingNumList[i] <- sum(edgeList[,8]<0 & edgeList[,8]>-40)
      largeImpulseNumList[i] <- sum(edgeList[,6]>100 & (edgeList[,1]== 31 | edgeList[,1] == 32 | edgeList[,1] == 33 | edgeList[,1] == 34))

    } else if(edgeNumList[i] == 1){
      maxSlopeMeanList[i] <- edgeList[,6]
      maxSlopeVarList[i] <- 0
      minSlopeMeanList[i] <- edgeList[,8]
      minSlopeVarList[i] <- 0
      smallRisingNumList[i] <- sum(edgeList[,6]>0 & edgeList[,6]<40)
      smallFallingNumList[i] <- sum(edgeList[,8]<0 & edgeList[,8]>-40)
      largeImpulseNumList[i] <- sum(edgeList[,6]>100 & (edgeList[,1]== 31 | edgeList[,1] == 32 | edgeList[,1] == 33 | edgeList[,1] == 34))
    } else {
      maxSlopeMeanList[i] <- 0
      maxSlopeVarList[i] <- 0
      minSlopeMeanList[i] <- 0
      minSlopeVarList[i] <- 0
      smallRisingNumList[i] <- 0
      smallFallingNumList[i] <- 0
      largeImpulseNumList[i] <- 0
    }





    ## flat features
    if (nrow(flatList)>1){
      flatDiff <- blockAp[flatList[,2]] - blockAp[flatList[,1]]
      flatDiffVarList[i] <- var(flatDiff)
      flatLengthVarList[i] <- var(flatList[,3])
    } else{
      flatDiffVarList[i] <- 0
      flatLengthVarList[i] <- 0
    }
    flatNumList[i] <- nrow(flatList)
    ## ap features
    medianMinDiffList[i] <- median(blockAp) - min(blockAp);
    quantile1MinDiffList[i] <- quantile(blockAp, 0.25, 4) - min(blockAp)
    meanLargerThanMedianList[i] <- mean(blockAp)>median(blockAp)

    # 7 diff features
    diff7 <- blockAp[8:length(blockAp)] - blockAp[1:(length(blockAp)-7)]
    diff7MeanList[i] <- mean(diff7)
    diff7VarList[i] <- var(diff7)
    diff7SmallCountList[i] <- sum(abs(diff7)<15)
    diff7LargeCountList[i] <- sum(abs(diff7)>30 & abs(diff7)<60)

    # 30 diff features
    diff30 <- blockAp[31:length(blockAp)] - blockAp[1:(length(blockAp)-30)]
    diff30MeanList[i] <- mean(diff30)
    diff30VarList[i] <- var(diff30)
    diff30SmallCountList[i] <- sum(abs(diff30)<15)
    diff30LargeCountList[i] <- sum(abs(diff30)>30 & abs(diff30)<60)

  }

  featureTable <- cbind(type11NumList, type12NumList, type21NumList, type22NumList, type31NumList, type32NumList,
                        type33NumList, type34NumList, edgeNumList, maxSlopeMeanList, maxSlopeVarList, minSlopeMeanList, minSlopeVarList,
                        smallRisingNumList, smallFallingNumList, largeImpulseNumList, medianMinDiffList, quantile1MinDiffList, meanLargerThanMedianList,
                        stringLengthMaxList, stringLengthMeanList, stringLengthVarList, diff7MeanList, diff7VarList, diff7SmallCountList, diff7LargeCountList,
                        diff30MeanList, diff30VarList, diff30SmallCountList, diff30LargeCountList, flatDiffVarList, flatLengthVarList, flatNumList)

  return(featureTable)

}



#' @title tvReconstructor
#' @author CH
#' @description reconstruct tv active power sequence using classified block state
#' @update 2015.12.03
#' @input blockStateList : predicted block on-off state
#'        data : total data c(timestamp, active_power, reactive power)
#'        blockSize
#'        tvApValue : active power of tv-on state
#' @output tv active_power vector
#'


######################################################################################################################


tvReconstructor <- function(blockStateList, data, blockSize, tvApValue)
{

  tv_ap = rep(0, length(data[,1]))

  # blockState on -> tvApValue
  for (i in 1:length(blockStateList)){
    if (blockStateList[i]==1){
      tv_ap[((i-1)*blockSize+1):(i*blockSize)] = tvApValue
    }
  }

  # reconstruct last thrown away part
  if (blockStateList[length(blockStateList)]==1){
    tv_ap[((i*blockSize)+1):length(tv_ap)] = tvApValue
  }

  return(tv_ap)
}



######################################################################################################################

#' @title tvStateExtractor
#' @author CH
#' @description extract tv state on total data from tv data and total data
#' @update 2015.12.03
#' @input totalData : c(timestamp, active_power, reactive_power)
#'        tvData : tv c(timestamp, active_ower, reactive_power)
#'        blockSize : classification time size
#' @output tv state vector
#'         e.g. 0 0 0 1 1 1 1 1 1 1 1 1 1 1 0...
#'
#'
#'
#'
#'
tvStateExtractor <- function(totalData, tvData, blockSize)
{
  total_ts <- totalData[,1]
  total_ap <- totalData[,2]
  total_rp <- totalData[,3]

  tv_ts <- tvData[,1]
  tv_ap <- tvData[,2]
  tv_rp <- tvData[,3]
  onThreshold <- 2 # if tv_ap >= (min(tv_ap))+onThreshold, tv_state = 1

  tv_state <- (tv_ap>=(min(tv_ap)+onThreshold))

  # tv on-off point
  tv_start <- rep(0, length(tv_ap))
  tv_end <- rep(0, length(tv_ap))

  # case handling : first time block on-off
  if (tv_state[1]==1){
    tv_start[1] <- 1
  }

  # (i-1)th state : off & ith state : on ->start
  for (i in 2:length(tv_state)){
    tv_start[i] <- ((tv_state[i]==1)&&(tv_state[i-1]==0))
  }


  # (i-1)th state : on & ith state : off -> end
  for (i in 1:(length(tv_state)-1)){
    tv_end[i] <- tv_state[i]==1&&tv_state[i+1]==0
  }

  # case handling : last time block on-off
  if (sum(tv_start)>sum(tv_end)){
    tv_end[length(tv_ap)] <- 1
  }

  tv_OnTime <- cbind(tv_ts[which(tv_start>0)], tv_ts[which(tv_end>0)])

  # label tv-state on total data
  tv_stateOnTotal <- rep(0, length(total_ap))

  if (nrow(tv_OnTime)>0){
    for (i in 1:length(tv_stateOnTotal)){
      for (j in 1:size(tv_OnTime,1)){
        if ((total_ts[i]>=tv_OnTime[j,1])&(total_ts[i]<=tv_OnTime[j,2]))
          tv_stateOnTotal[i] <- 1
      }
    }
  }

  # if 1/5 of block is on, block state is on.
  tv_blockState = rep(0, floor(length(tv_stateOnTotal)/blockSize))
  for (i in 1:length(tv_blockState)){
    blockSum = sum(tv_stateOnTotal[((i-1)*blockSize+1):(i*blockSize)])
    if (blockSum>(blockSize/5)){
      tv_blockState[i]<-1
    }
  }

  return(tv_blockState)
}
