

extractActivation = function( df, app = NULL, total = F, maxGap = 30*60, minP = 200, margin = 20 ){
  if( is.null( appliance ) ){ dataAppliance = subset( df, appliance == df$appliance[1] )
  }else dataAppliance = subset( df, appliance == app )
  
  if( nrow( dataAppliance ) == 0 ) stop( "extractActivation: no data" )
    
  dataAppliance$act = dataAppliance$active_power > minP
  
  myrle = rle( dataAppliance$act )  
  dataAppliance$rle = do.call( "c", lapply( myrle$length, function(x) rep( x, each = x ) ) )
 
  mywhich = which( myrle$lengths > maxGap & !myrle$values )
  
  if( length( mywhich ) == 0 ){ # all activation 
    out = list( dataAppliance ) 
  }else if( myrle$lengths[1] == nrow(dataAppliance)){
    out = list()
  }else{ 
  
    temp2 = sapply( mywhich, function(x){
      out = c()
      if( x == 1 ) out[1] = 1 else out[1] = sum( myrle$lengths[1:(x-1)] )
      out[2] = out[1] + myrle$length[x]
      out
    } )
  
    if( temp2[1] == 1 ) temp2 = temp2[-1] else temp2 = c( 1, temp2 )
    if( temp2[length(temp2)] == nrow( dataAppliance ) ) temp2 = temp2[ -length(temp2) ] else temp2 = c( temp2, nrow(dataAppliance) )
  
    temp3 = matrix( temp2, nrow = 2 )
  
    out = lapply( 1:ncol(temp3), function(x) dataAppliance[ max( 1, temp3[1,x] - margin):min( temp3[2,x] + margin, nrow(dataAppliance) ),] )  
  }

  # output total data too
  if( total ){
    dataTotal = subset( df, appliance == "총량" )
    totalExtract = function( oneData ){

      startIndex = which.min( abs( dataTotal$timestamp - min( oneData$timestamp ) ) )
        endIndex = which.min( abs( dataTotal$timestamp - max( oneData$timestamp )  ) )
      
      dataTotal[startIndex:endIndex,]
    }
    
    out = lapply( out, function(x) rbind(x[,-c(ncol(x)-0:1)], totalExtract(x)) )   
  }
  
  out
}


