#scp -r nilm@192.168.100.10:/home/nilm/CloudNilm/src/nilm_core ./src/
scp -r nilm@192.168.100.10:/home/nilm/CloudNilm/src/nilm_core/*  /Users/kasugare/Work/Encored/analytics_master/src/nilm_worker/job_container/nilm/nilm_core/
