1. Install Packages
====
Go to the folder libs and type the following commands:
* R CMD INSTALL plyr_1.8.1.tar.gz
* R CMD INSTALL lubridate_1.3.3.tar.gz
* R CMD INSTALL plots_1.2.3.tar.gz
* R CMD INSTALL reshape_0.8.5.tar.gz
* R CMD INSTALL scales_0.2.5.tar.gz
* R CMD INSTALL clue_0.3-50.tar.gz
* R CMD INSTALL NILM1Hz_1.2.tar.gz
* R CMD INSTALL evaluateNILM_1.0.4.tar.gz
* R CMD INSTALL encoredDB_2.1.3.tar.gz
* R CMD INSTALL encoredLog_2.5.0.tar.gz 

* apt-get install python-pandas
* apt-get install python-rpy2
* pip install -r requirements.txt

2. Run the script for test
====
Go to the folder pyefingerprint and type the following:
* cd test_nilm
* python main.py

3. Run the script
====
Go th the folder NilmCluster and type the following:
* cd src/
* python NilmCluster.py -p 2015-07-01_00:00:00 2015-07-07_23:59:59 -s 'site_id'

