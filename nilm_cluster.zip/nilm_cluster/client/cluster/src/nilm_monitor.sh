#!/bin/bash

#while true;
#do
watch -n 2 python /Users/kasugare/Work/Encored/nilm_cluster/client/cluster/src/NilmClient.py --RESOURCES=all
#sleep 2
#done




