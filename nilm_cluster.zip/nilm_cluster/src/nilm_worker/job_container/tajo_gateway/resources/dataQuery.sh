#/bin/bash

/home/tajo/tajo/bin/tsql -c "$1;"