#!/usr/bin/env python
# -*- coding: utf-8 -*-

class ClientOrderSheetChecker:
    def __init__(self, logger):
        self._logger = logger