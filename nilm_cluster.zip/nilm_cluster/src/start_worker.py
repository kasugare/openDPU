~/processKill.sh
python NilmCluster.py worker
